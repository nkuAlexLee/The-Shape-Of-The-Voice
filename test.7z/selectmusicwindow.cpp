#include "selectmusicwindow.h"
#include "ui_selectmusicwindow.h"
#include"gamewindow.h"
#include"UIdesign.h"
SelectMusicWindow::SelectMusicWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SelectMusicWindow)
{

    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
    setWindowFlags(Qt::WindowStaysOnTopHint);
//    QString num = QString::number(qrand()%15+1);
//    ui->PictureLabel->setPixmap(QPixmap(":/pic/picture/background ("+num+").png"));
    init();
    PlayerList->setCurrentIndex(0);
    connect(ui->musicname,SIGNAL(cellClicked(int,int)),this,SLOT(seekMusic(int,int)));
    ui->musicname->verticalHeader()->setDefaultSectionSize(134);
    ui->musicname->verticalHeader()->setHidden(true);
    ui->musicname->setFocusPolicy(Qt::NoFocus);
    ui->musicname->setFrameShape(QFrame::NoFrame);

    //ui->musicname->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    for (int i=0;i<ui->musicname->rowCount();i++)
    {
         ui->musicname->item(i,0)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
         ui->musicname->item(i,0)->setFont(QFont("幼圆", 15));
         ui->musicname->item(i,0)->setBackgroundColor(TRANSPARENT);
    };

}

SelectMusicWindow::~SelectMusicWindow()
{
    delete ui;
}
void SelectMusicWindow::goToOtherPage()
{
    p=new MainWindow(this,(((MainWindow*)p))->player,(((MainWindow*)p))->medialist,(((MainWindow*)p))->backgroundMusic,(((MainWindow*)p))->musiclist);
    ((MainWindow*)p)->hide();
    this->playInterimgif1();
    QTimer::singleShot(3000,this, [=](){
        this->close();
        ((MainWindow*)p)->show();
        ((MainWindow*)p)->m_digitalZoomWidget->show();
    });
    delete lrcList;
    delete PlayerList;
    delete Player;
}
void SelectMusicWindow::init(){
    PlayerList = new QMediaPlaylist;  //实例化播放器和播放列表
    Player = new QMediaPlayer;
    fileList = getFileNames(this->MusicPath);  //获取文件夹下所有音乐文件
    *lrcList = getLrcNames(this->LrcPath);
      //moved = 0;
      qDebug()<<"ALL Music File \n"<<fileList;
      qDebug()<<"ALL Lrc File \n"<<lrcList;

      for(int i=0;i<fileList.size();i++){
        QString fileName=fileList.at(i);
        QString filename=fileName.left(fileName.size() - 4);
        addItem(filename);
        PlayerList->addMedia(QUrl::fromLocalFile(MusicPath+"\\"+fileName));
      }
      PlayerList->setCurrentIndex(1);
      Player->setPlaylist(PlayerList);
      ui->musicname->setSelectionMode (QAbstractItemView::SingleSelection);
      ui->musicname->setCurrentCell(0,0);
      fileName=fileList.at(0);
      QString filename=fileName.left(fileName.size() - 4);
      int soc=readHighScore(filename,0,0);
      int fin=readHighFinished(filename,0,0);
      playdegree(soc,fin,ui->pic,ui->score,ui->finished);
      QString  tableQss= loadStyle(":/qss/qss/tablewidget.txt");
      ui->musicname->setStyleSheet(tableQss);
}
void SelectMusicWindow::addItem(QString name){
  int count = ui ->musicname->rowCount();
  ui->musicname->setRowCount(count+1);
  QTableWidgetItem *itemName = new QTableWidgetItem(name);
  ui->musicname->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
  itemName->setFlags(itemName->flags() & ~Qt::ItemIsEditable);
  ui->musicname->setItem(count,0,itemName);
}
QStringList SelectMusicWindow::getFileNames(const QString &path)
{
  QDir dir(path);
  QStringList nameFilters;
  nameFilters << "*.mp3";
  QStringList files = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
  return files;
}

QStringList SelectMusicWindow::getLrcNames(const QString &path)
{
  QDir dir(path);
  QStringList nameFilters;
  nameFilters <<"*.txt";
  QStringList files = dir.entryList(nameFilters, QDir::Files|QDir::Readable, QDir::Name);
  return files;
}
void SelectMusicWindow::seekMusic(int i,int )
{
  PlayerList->setCurrentIndex(i);
  Player->setPlaylist(PlayerList);
  fileName=fileList.at(i);
  QString filename=fileName.left(fileName.size() - 4);
  int soc=readHighScore(filename,0,0);
  int fin=readHighFinished(filename,0,0);
  playdegree(soc,fin,ui->pic,ui->score,ui->finished);
  qDebug()<<fileName;
}
QString SelectMusicWindow::loadStyle(QString const website){
        QString qss;
        QFile qssFile(website);
        qssFile.open(QFile::ReadOnly);
        if(qssFile.isOpen())
        {
            qss = QLatin1String(qssFile.readAll());
            qssFile.close();
        }
        return qss;
    };
void SelectMusicWindow::on_BackButtom_2_clicked()
{
    //
    //delete music;
    this->close();
    QString filename=(SelectMusicWindow::fileName.left(SelectMusicWindow::fileName.size() - 4));
    GameWindow* g=new GameWindow(nullptr,filename);
    //跳转到下个页面
    qDebug()<<&fileName<<fileName;
    qDebug()<<&(g->filename)<<(g->filename);

    g->show();
    g->p=p;
    //g->findBug();
    //this->close();
    (((MainWindow*)p))->player->stop();
    ((MainWindow*)p)->backgroundMusic->stop();
    delete lrcList;
    delete PlayerList;
    delete Player;

}


void SelectMusicWindow::on_BackButtom_clicked()
{
    goToOtherPage();
    //跳转到主页面
}

