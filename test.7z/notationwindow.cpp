#include "notationwindow.h"
#include "ui_notationwindow.h"
#include "mainwindow.h"
#include "UIdesign.h"
#include <fstream>
#include <iostream>
#include<QScrollBar>
#include<QTime>
#include <QKeyEvent>
#include<cstring>
#include <QString>
#include"GlobalData2.h"
NotationWindow::NotationWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NotationWindow)
{

    this->playInterimgif1();
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));

    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
    setWindowFlags(Qt::WindowStaysOnTopHint);
    ui->key1->setText((QString)(char)leftmost_track);
    ui->key2->setText((QString)(char)left_track);
    ui->key3->setText((QString)(char)right_track);
    ui->key4->setText((QString)(char)rightmost_track);
    timer = new QTimer();
       timer->setInterval(25);

       QPixmap pixmap;
       pixmap = QPixmap(1280, 388);
       pixmap.fill(Qt::white);
       QPainter painter(this);
       painter.setPen(QPen(Qt::red,4));
       painter.drawLine(50,0,50,388);//画直线


       // 使用 pixmap
       ui->label_3->setPixmap(pixmap);

       player = new QMediaPlayer(this);

       /*<----------------------------这里设置icon--------------------------------->*/
       ic_1.addFile(":/pic/picture/none.png");              //默认icon
       ic_2.addFile(":/pic/picture/short.png");            //短按icon
       ic_3.addFile(":/pic/picture/long.png");            //长按icon
       /*<------------------------------------------------------------------------->*/


       memset(btn_state,0,sizeof(btn_state));
       memset(track_state,0,sizeof(track_state));

       init_key_signal();

       QString curPash =QDir::currentPath()+"/resourse/stave/temp.txt";
       std::string str = curPash.toStdString();
       nowPash = str.c_str();
       qDebug()<<curPash;
       qDebug()<<"nowPash:"<<nowPash;
       output_temp = new ofstream(nowPash,ios_base::out);
//       tim = new QTimer();
//       tim->setInterval(500);
//       connect(tim,&QTimer::timeout,this,[=](){
//           if(player!=nullptr){
//               musicPositionChange(0);
//           }
//       });
       disconnect(ui->horizontalSlider,&QSlider::sliderMoved,this,&NotationWindow::on_horizontalSlider_sliderMoved);
       NOW_STATE = 1;
       setBtn();


}

NotationWindow::~NotationWindow()
{
    qDebug()<<"Destructure !";

        q_file->close();
        output_temp->close();
        for(int i = 0;i<4;i++){
            for(int j = 0;j<Tot_knot;j++){
                delete btn[i][j];
            }
        }
        delete output_temp;
        delete q_file;
        delete player;
        delete timer;
        delete ui;
}

//void NotationWindow::fileEmpty(const string fileName)
//{
//    fstream file(fileName, ios::out);
//    file.close();
//}

void NotationWindow::fileEmpty(const string fileName)
{
    QString curPash =QDir::currentPath()+"/resourse/stave/temp.txt";
    std::string str = curPash.toStdString();
    nowPash = str.c_str();
    QFile file(nowPash);
    file.open(QFile::WriteOnly|QFile::Truncate);
    file.close();
}
void NotationWindow::goToOtherPage()
{
    p=new MainWindow(this,(((MainWindow*)p))->player,(((MainWindow*)p))->medialist,(((MainWindow*)p))->backgroundMusic,(((MainWindow*)p))->musiclist);
    ((MainWindow*)p)->hide();
    this->playInterimgif1();
    QTimer::singleShot(3000,this, [=](){
        this->close();
        ((MainWindow*)p)->show();
        ((MainWindow*)p)->m_digitalZoomWidget->show();
    });

}
void NotationWindow::slotBtnClick()
{
    player->stop();
    ui->horizontalSlider->setValue(0);
    (((MainWindow*)p))->player->stop();
    ((MainWindow*)p)->backgroundMusic->pause();
    QString curPash =QDir::currentPath();
    QString nowPash=curPash+"/music_game_data/player/music";
    qDebug()<<curPash;

    QString dlgTitle="选择音频文件";
    QString filter="音频文件(*.mp3 *.wav *.wma)mp3文件(*.mp3);;wav文件(*.wav);;wma文件(*.wma);;所有文件(*.*)";
    fileList = QFileDialog::getOpenFileName(this,dlgTitle,nowPash,filter);

    QFileInfo l_info(fileList);
    filetext = curPash+"/music_game_data/player/file/"+l_info.fileName().left(l_info.fileName().size() - 4);

    qDebug()<<fileList;
    if (!filetext.isEmpty())
    {
        q_file = new QFile(filetext + ".txt");
        if(q_file->exists(filetext + ".txt")){
           qDebug()<<"exist";
           is_created = true;
           get_stave();
        }
        else{
           if(!q_file->open(QIODevice::WriteOnly | QIODevice::Text)){
               qDebug() << "Open failed." << endl;
               return;
           }
           else {
               is_created=true;
               qDebug()<<"SUCSS CREATE　FILE!";
               QTextStream out(q_file);
               for(int i = 0;i<20;i++){
                   out<<"0000\n";
               }
           }
        }
        q_file->close();
        player->setMedia(QUrl::fromLocalFile(fileList));
            //(((MainWindow*)p))->player->stop();
        player->setVolume(music_volume);
        emit ui->pushButton_3->clicked();
        player->play();
        is_playing = true;
        emit ui->pushButton_3->clicked();
        connect(player, &QMediaPlayer::positionChanged, this, &NotationWindow::musicPositionChange);
    }
    else{
        ((MainWindow*)p)->backgroundMusic->play();
    }
}

QString NotationWindow::formatTime(int ms)
{
    int ss = 1000;
    int mi = ss * 60;
    int hh = mi * 60;
    int dd = hh * 24;

    long day = ms / dd;
    long hour = (ms - day * dd) / hh;
    long minute = (ms - day * dd - hour * hh) / mi;
    long second = (ms - day * dd - hour * hh - minute * mi) / ss;
    long milliSecond = ms - day * dd - hour * hh - minute * mi - second * ss;

    QString hou = QString::number(hour,10);
    QString min = QString::number(minute,10);
    QString sec = QString::number(second,10);
    QString msec = QString::number(milliSecond,10);

    //qDebug() << "minute:" << min << "second" << sec << "ms" << msec <<endl;

    return hou + ":" + min + ":" + sec ;
};
void NotationWindow::on_BackButtom_clicked()
{
    delete player;
    player=nullptr;
    goToOtherPage();
}

void NotationWindow::on_BackButtom_4_clicked()
{
    isRead=true;
    slotBtnClick();
}


void NotationWindow::on_horizontalSlider_valueChanged(int value)
{
    if(musicPositionChangeFlag){
        player->setPosition(value*player->duration()/1000);
    }
    QString currentTime=formatTime(player->position());
    QString maxTime=formatTime(player->duration());
    ui->label_6->setText(currentTime+"/"+maxTime);
}

void NotationWindow::musicPositionChange(qint64 position=0){
    int value=player->position()*1000/player->duration();
    qDebug()<<"value:"<<value;
    ui->horizontalSlider->setSliderPosition(value);
}
//void NotationWindow::updateTimeLine(qint64 position){
//    int value=player->position()*100/player->duration();
//    qDebug()<<"value:"<<value;
//    ui->horizontalSlider->setSliderPosition(value);
//}

void NotationWindow::on_horizontalSlider_sliderPressed()
{
    if(isRead){
    musicPositionChangeFlag=true;
     disconnect(ui->horizontalSlider,&QSlider::sliderMoved,this,&NotationWindow::on_horizontalSlider_sliderMoved);}
}


void NotationWindow::on_horizontalSlider_sliderReleased()
{
    if(isRead){
    musicPositionChangeFlag=false;
     disconnect(ui->horizontalSlider,&QSlider::sliderMoved,this,&NotationWindow::on_horizontalSlider_sliderMoved);}
}


void NotationWindow::on_pushButton_3_clicked()
{
    if(isRead){
        if(musicPlayed){
                player->pause();
                musicPlayed=false;
                disconnect(timer,&QTimer::timeout,this,&NotationWindow::scrollPositionChange);
                qDebug()<<"SUCC!";
            }
            else{
                player->play();
                musicPlayed=true;
                connect(timer,&QTimer::timeout,this,&NotationWindow::scrollPositionChange);
                timer->start();
            }
    }
}

//改为短按状态
void NotationWindow:: on_shortknock_clicked(){
    NOW_STATE = 1;
    qDebug()<<"NOW_STATE = 1";
}

//改为长按状态
void NotationWindow::on_longknock_clicked()
{
    NOW_STATE = 2;
    qDebug()<<"NOW_STATE = 2";
}

//改为无状态
void NotationWindow::on_longknock_2_clicked()
{
    NOW_STATE = 0;
    qDebug()<<"NOW_STATE = 0";
}


//改变滑动窗口状态，向右滑动
void NotationWindow:: scrollPositionChange(){
    if(isRead){
    if(player!=nullptr&&player->state()==QMediaPlayer::PlayingState){
        NOW_SCRO_POS += 8;
        //如果越过了基准线
        if(NOW_SCRO_POS%80 == 0){
            NOW_ROW++;
            for(int i = 0;i<4;i++){
                change_off_line(NOW_ROW,i);
            }
        }
//        QScrollBar * scr_bar = ui->scrollArea->horizontalScrollBar();
//        scr_bar->setValue(NOW_SCRO_POS);
    }
    QScrollBar * scr_bar = ui->scrollArea->horizontalScrollBar();
    scr_bar->setValue(NOW_SCRO_POS);}
}


//根据乐谱确定按钮样式
void NotationWindow::setBtn(){
    for(int i = 0;i<4;i++){
        for(int j=0;j<Tot_knot;j++){
            //qDebug()<<"HERE!!";
            int x = (j+1)*80-30;
            int y = (i+1)*80-30;
            btn[i][j] = new QPushButton(ui->scrollAreaWidgetContents);
            btn[i][j]->move(x,y);
            btn[i][j]->resize(80,80);
            btn[i][j]->setStyleSheet(
                        "QPushButton{"                             // 正常状态样式
                                    "border-radius: 40px;"                      // 边框圆角半径像素
                                    "border-style:outset;"                     // 定义一个3D突出边框，inset与之相反
                                    "}"

            );
            btn[i][j]->setIcon(ic_1);
            btn[i][j]->setIconSize(QSize(80,80));

            //连接 点击-槽
            connect(btn[i][j],&QPushButton::clicked,ui->label_3,[=](){
                QTimer::singleShot(100, this,SLOT());
                btn_state[i][j] = NOW_STATE;
                if(j>CNT_STAVE_ROW)CNT_STAVE_ROW = j+1;
                //重写文本文件
                re_write_stave(output_temp);
                //修改btn[i][j]的qss样式
                if(btn_state[i][j] == 0){
                    //预留icon_0
                    /*<-------------------这里是添加icon代码------------------------->*/
                     btn[i][j]->setIcon(ic_1);
                     btn[i][j]->setIconSize(QSize(80,80));
                    /*<------------------------------------------------------------>*/
                }
                else if(btn_state[i][j] == 1){
                    /*<-------------------这里是添加icon代码------------------------->*/
                     btn[i][j]->setIcon(ic_2);
                     btn[i][j]->setIconSize(QSize(80,80));
                    /*<------------------------------------------------------------>*/
                }
                else if(btn_state[i][j] == 2){
                    /*<-------------------这里是添加icon代码------------------------->*/
                     btn[i][j]->setIcon(ic_3);
                     btn[i][j]->setIconSize(QSize(80,80));
                    /*<------------------------------------------------------------>*/
                }
            });
        }
    }
}


//获取乐谱
void NotationWindow::get_stave(){

    CNT_STAVE_ROW = 0;
    q_file->open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream in(q_file);
    QString s;
    int row=-19;
    do{
        s = in.readLine();
        if(s[0]  < '0'||row<0){row++;continue;};
        string temp = QString_to_String(s);
        for(int j = 0;j<4;j++){
            btn_state[j][CNT_STAVE_ROW] = temp[j] - '0';
        }
        CNT_STAVE_ROW++;        //记录曲谱多少行
    }while(!s.isNull());

        //改变按钮状态
        for(int i = 0;i<4;i++){
            for(int j = 0;j<CNT_STAVE_ROW;j++){
                if(btn_state[i][j] == 0){
                    //按钮名称为btn[i][j]
                    /*<-------------------这里是添加icon代码------------------------->*/
                    btn[i][j]->setIcon(ic_1);
                    btn[i][j]->setIconSize(QSize(100,100));
                    /*<------------------------------------------------------------>*/
                }
                else if(btn_state[i][j] == 1){
                    /*<-------------------这里是添加icon代码------------------------->*/
                    btn[i][j]->setIcon(ic_2);
                    btn[i][j]->setIconSize(QSize(80,80));
                    /*<------------------------------------------------------------>*/
                }
                else if(btn_state[i][j] == 2){
                    /*<-------------------这里是添加icon代码------------------------->*/
                    btn[i][j]->setIcon(ic_3);
                    btn[i][j]->setIconSize(QSize(80,80));
                    /*<------------------------------------------------------------>*/
                }
            }
        }
        q_file->close();

}


//初始化所有按钮





//输出乐谱.txt文件
void NotationWindow:: re_write_stave(ofstream *output){      //用文件temp存储副本txt，整个游戏用这一个txt当副本就好了
    fileEmpty(nowPash);
    if(!output)qDebug()<<"WRONG!";
    qDebug()<<"我只是想保存一下";
    string temp = "0000";
    for(int i  =0;i<CNT_STAVE_ROW;i++){
        for(int j = 0;j<4;j++){
            temp[j] = btn_state[j][i] + '0';
            if(btn_state[j][i]<0){
                btn_state[j][i]=btn_state[j][i]+48;
            }
            //qDebug()<<"outputtemp"<<j<<"="<<temp[j];
        }
        cout<<"temp is "<<temp<<endl;
        if(temp[0]=='0'||temp[0]=='1'||temp[0]=='2'){
            *output<<temp<<endl;
        }
    }
    //output->close();
//    for(int i = 0;i<CNT_STAVE_ROW;i++){
//        for(int j = 0;j<4;j++){
//            cout<<btn_state[j][i]<<" ";
//        }
//        cout<<endl;
//    }
//    cout<<endl;

    //output.close();
}

void NotationWindow:: change_off_line(int x,int y){
}


void NotationWindow::on_pushButton_clicked()
{
    if(isRead){
    scrollPositionChange();}
}

void NotationWindow:: keyPressEvent(QKeyEvent *ev){


    setFocusPolicy(Qt::StrongFocus);
    int press_key=ev->key();
    if(press_key==leftmost_track){
        if(ev->isAutoRepeat()){
            QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
            emit this->longpress(0);

            return;
        }
            qDebug()<<"CLICK!!!!";
            QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
            emit this->press(0);
    }else if(press_key==left_track){
        if(ev->isAutoRepeat()){
            QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
            emit this->longpress(1);
            return;
        }
        qDebug()<<"CLICK!!!!";
        emit this->press(1);
    }else if(press_key==right_track){
        if(ev->isAutoRepeat()){
            QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
            emit this->longpress(2);
            return;
        }
        qDebug()<<"CLICK!!!!";
        QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
        emit this->press(2);
    }else if(press_key==rightmost_track){
        if(ev->isAutoRepeat()){
            QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
            emit this->longpress(3);
            return;
        }
        qDebug()<<"CLICK!!!!";
        QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
        emit this->press(3);
    }
}

void NotationWindow::keyReleaseEvent(QKeyEvent *ev){

    setFocusPolicy(Qt::StrongFocus);
    int release_key=ev->key();
    if(release_key==leftmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        QTimer::singleShot(100, this,SLOT(emitMusicChanged()));
        emit this->release(0);
    }else if(release_key==left_track){
        if(ev->isAutoRepeat()){
            return;
        }
        emit this->release(1);
    }else if(release_key==right_track){
        if(ev->isAutoRepeat()){
            return;
        }
        emit this->release(2);
    }else if(release_key==rightmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        emit this->release(3);
    }
}

void NotationWindow:: init_key_signal(){
   connect(this,&NotationWindow::longpress,this,&NotationWindow::imitate_long_click);

   connect(this,&NotationWindow::press,this,&NotationWindow::imitate_short_click);

   connect(this,&NotationWindow::release,this,&NotationWindow::cancel_imitate_click);
}

void NotationWindow::imitate_short_click(int y){
    emit this->ui->shortknock->clicked();
    emit btn[y][NOW_ROW]->clicked();
    qDebug()<<"CLICK";
    return;
}

void NotationWindow:: imitate_long_click(int y){
    track_state[y] = 2;
    for(int i = 0;i<4;i++){
        if(track_state[i] ==2){
            emit this->ui->longknock->clicked();
            emit btn[i][NOW_ROW]->clicked();
            emit btn[i][NOW_ROW-1]->clicked();
            emit btn[i][NOW_ROW-2]->clicked();
            qDebug()<<"CLICK";
        }
    }
    return;
}

//void NotationWindow::imitate_click(int y){

//}


void NotationWindow::on_BackButtom_3_clicked()
{
    if(isRead){
    QString curPash =QDir::currentPath()+"/resourse/stave/temp.txt";
    std::string str = curPash.toStdString();
    nowPash = str.c_str();
    QFile infile_2(nowPash);
    infile_2.close();
    qDebug()<<"nowPash当前地址是"<<nowPash;

    QFile *q_file = new QFile(filetext+".txt");
    if(q_file->open(QIODevice::WriteOnly | QIODevice::Text | QFile::Truncate)){
         qDebug() << "Open SUCC." << endl;
     }
    else{
        qDebug()<<"WRTING WRONG";
    }

    QString s;
    if(infile_2.open(QIODevice::ReadOnly|QIODevice::Text)){
        qDebug()<<"HERE!!";
        QTextStream in(&infile_2);
        QTextStream out(q_file);
        for(int i = 0;i<20;i++){
            out<<"0000\n";
        }
        s = in.readLine();
        int n=0;
        while(!s.isNull()){
            s = in.readLine();
            if(n==0&&(s[0]=='0'||s[0]=='1'||s[0]=='2')){
                out<<s;
                n=1;
                qDebug()<<"s = "<<s;
            }
            else if((s[0]=='0'||s[0]=='1'||s[0]=='2')){
                out<<"\n"<<s;
                qDebug()<<"s = "<<s;
            }
        }
    }
    //infile_2.close();
    q_file->close();
    delete q_file;
    }

}

string NotationWindow::QString_to_String(QString q_s){
    QByteArray ba = q_s.toLatin1();
    string s;
    s = ba.data();
    return s;
}

void NotationWindow::cancel_imitate_click(int y){
    track_state[y] = 0;
}

void NotationWindow::scroll_slider_change(int val){
    qDebug()<<"scroll_slider_change!"<<" val is "<<val;
    QScrollBar * scr_bar = ui->scrollArea->horizontalScrollBar();


    //更新现位置
    NOW_SCRO_POS = val*80;
    NOW_ROW = val;
    scr_bar->setValue(val*80);

    qDebug()<<"HERE scroll_slider_change";

    delete scr_bar;
    return;
}


void NotationWindow::on_horizontalSlider_sliderMoved(int val)
{
    if(isRead){
    qDebug()<<"scroll_slider_change!"<<" val is "<<val;
    QScrollBar * scr_bar = ui->scrollArea->horizontalScrollBar();
    scr_bar->setValue(val*80);

    //更新现位置
    NOW_SCRO_POS = val*80;
    NOW_ROW = val;}


}




void NotationWindow::on_BackButtom_2_clicked()
{
    if(isRead){
    fileEmpty(nowPash);
    get_stave();}
}

