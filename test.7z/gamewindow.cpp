#include "gamewindow.h"
#include "ui_gamewindow.h"
#include "UIdesign.h"
#include "GlobalData2.h"
#include <QScreen>
#include<QSound>
GameWindow::GameWindow(QWidget *parent,QString filename) :
    QWidget(parent),
    ui(new Ui::GameWindow)
{
    isBegin=true;
    //gotoEndpage();
    setFocusPolicy(Qt::StrongFocus);
    this->grabKeyboard();
    qDebug()<<"GameWindow";
    ui->setupUi(this);
    ui->label_1->setText((QString)(char)leftmost_track);
    ui->label_2->setText((QString)(char)left_track);
    ui->label_3->setText((QString)(char)right_track);
    ui->label_4->setText((QString)(char)rightmost_track);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
//    QString num = QString::number(qrand()%15+1);
//    ui->PictureLabel->setPixmap(QPixmap(":/pic/picture/background ("+num+").png"));
    GameWindow::filename=filename;
    //QTimer *timer = new QTimer(this); //this 为parent类, 表示当前窗口
    //connect(timer, SIGNAL(timeout()), this, SLOT(GameCubeDown())); // SLOT填入一个槽函数
    timer=new QTimer(this);
    timer1=new QTimer(this);
    timer2=new QTimer(this);
    timer3=new QTimer(this);
    timer_321=new QTimer(this);
    connect(timer1,&QTimer::timeout,[=](){
        finished=(float)(success_press)/(float)(key_number)*100;
        qDebug()<<"finished:"<<finished;
        strfinished=QString::number(finished)+"%";
        strsuccess_press=QString::number(success_press);
        strscore=QString::number(total_score);
        ui->finished->setText(strfinished);
        ui->success->setText(strsuccess_press);
        ui->score->setText(strscore);
        if(!isPause){list.deleteNode();}});
    connect(timer,&QTimer::timeout,this,&GameWindow::time2);       //计时器
    connect(timer1,&QTimer::timeout,this,&GameWindow::time3);       //计时器
    connect(timer2,&QTimer::timeout,this,&GameWindow::time4);       //计时器
    connect(timer_321,&QTimer::timeout,this,&GameWindow::time321);
//    usage_patterns=1;
//    playGameMusic(filename,1);
    //GameCubeDown(0,1,1,0);
    //GameCubeDown(1,1,2,1500);
    qDebug()<<filename<<"全部运行";
    playGameMusic(filename,1);
    //playGif321();
    connect(game_music,&QMediaPlayer::mediaStatusChanged,this,&GameWindow::music_change);
    //GameLongCube(300,0.72,1500);
    //GameShortCube(300,0.72);
    game_music->pause();
    isPause=true;
    Begin();
    connect(this,&GameWindow::MusicChanged,this,[=](){
        if(isBegin==false){
            if(isPause&&list.head->flag==1){
                list.pauseNode();
                qDebug()<<"cube is pauesd";
            }
            else if(list.head->flag==1){
                list.startNode();
                qDebug()<<"cube is started";
            }
        }
    });
}

GameWindow::~GameWindow()
{
    delete game_music;
    delete ui;
    delete q;
    delete movie;
    delete successHitGifLabel1;
    delete successHitGifLabel2;
    delete successHitGifLabel3;
    delete successHitGifLabel4;
    delete successHitGifMovie1;
    delete successHitGifMovie2;
    delete successHitGifMovie3;
    delete successHitGifMovie4;

}
void GameWindow::deleteptr(){
    delete game_music;
    delete ui;
}
void GameWindow::Begin(){
    playGif321();
}
void GameWindow::music_change(){
    qDebug()<<"change正常运行";
    if(game_music->mediaStatus()==QMediaPlayer::EndOfMedia){
        qDebug()<<"END"<<endl;
        game_music->stop();
        timer->stop();
        timer1->stop();
        timer2->stop();
        playFinished();
    }
};
void GameWindow::gotoEndpage(){
    this->releaseKeyboard();
        GameOverWindow* g=new GameOverWindow(nullptr,finished,success_press,total_score,filename);
        this->close();
        deleteptr();
        //跳转到下个页面
        g->show();
        g->p=p;
        ((MainWindow*)g->p)->backgroundMusic->play();
    //g->findBug();
    //this->close();

}
QString GameWindow::loadStyle(QString const website){
    QString qss;
    QFile qssFile(website);
    qssFile.open(QFile::ReadOnly);
    if(qssFile.isOpen())
    {
        qss = QLatin1String(qssFile.readAll());
        qssFile.close();
    }
    return qss;
};
void GameWindow::playGreat(){
//    QLabel *q=new QLabel(this);
//    QMovie *movie = new QMovie(":/pic/picture/time321_once.gif");
//    q->setMovie(movie);
//    q->setGeometry(260,160,720,405);
//    q->setParent(this);
//    movie->start();
//    q->show();
//    connect(movie,&QMovie::stateChanged,[=](){
//            delete movie;
//            delete q;
//    });
}
void GameWindow::playFinished(){
        w2=new QLabel(this);
        w2->setGeometry(0,0,1280,720);
        w2->setParent(this);
        w2->setStyleSheet("background-color: rgba(0, 0, 0,150);");
        w2->show();
        q2=new QLabel(this);
        movie2 = new QMovie(":/pic/picture/finished.gif");
        q2->setMovie(movie2);
        q2->setGeometry(0,0,1280,720);
        q2->setParent(this);
        movie2->start();
        q2->show();
        connect(movie2,&QMovie::stateChanged,[=](){
            if(w2!=nullptr){
                delete w2;
                delete q2;
                delete movie2;
                q2=nullptr;
                movie2=nullptr;
                w2=nullptr;
            }
            QTimer::singleShot(100,nullptr, [=](){gotoEndpage();});
        });

}
void GameWindow::createSuccessHitGif(int n){

    if(n==1){
        if(successHitGifLabel1==nullptr){
            successHitGifLabel1=new QLabel(this);
            successHitGifMovie1 = new QMovie(":/pic/picture/touch.gif");
            successHitGifLabel1->setMovie(successHitGifMovie1);
            successHitGifLabel1->setGeometry(320,570,120,120);
            successHitGifLabel1->setParent(this);
            successHitGifMovie1->start();
            successHitGifLabel1->show();
        }
        connect(successHitGifMovie1,&QMovie::stateChanged,[=](){
            if(successHitGifLabel1!=nullptr&&successHitGifMovie1->state()<2){
                delete successHitGifLabel1;
                delete successHitGifMovie1;
                successHitGifLabel1=nullptr;
                successHitGifMovie1=nullptr;
            }
        });
        qDebug()<<"1号轨道点击";
    }
    else if(n==2){
        if(successHitGifLabel2==nullptr){
            successHitGifLabel2=new QLabel(this);
            successHitGifMovie2 = new QMovie(":/pic/picture/touch.gif");
            successHitGifLabel2->setMovie(successHitGifMovie2);
            successHitGifLabel2->setGeometry(480,570,120,120);
            successHitGifLabel2->setParent(this);
            successHitGifMovie2->start();
            successHitGifLabel2->show();
        }
        connect(successHitGifMovie2,&QMovie::stateChanged,[=](){
            if(successHitGifLabel2!=nullptr&&successHitGifMovie2->state()<2){
                delete successHitGifLabel2;
                delete successHitGifMovie2;
                successHitGifLabel2=nullptr;
                successHitGifMovie2=nullptr;
            }
        });
        qDebug()<<"2号轨道点击";
    }
    else if(n==3){
        if(successHitGifLabel3==nullptr){
            successHitGifLabel3=new QLabel(this);
            successHitGifMovie3 = new QMovie(":/pic/picture/touch.gif");
            successHitGifLabel3->setMovie(successHitGifMovie3);
            successHitGifLabel3->setGeometry(640,570,120,120);
            successHitGifLabel3->setParent(this);
            successHitGifMovie3->start();
            successHitGifLabel3->show();
        }
        connect(successHitGifMovie3,&QMovie::stateChanged,[=](){
            if(successHitGifLabel3!=nullptr&&successHitGifMovie3->state()<2){
                delete successHitGifLabel3;
                delete successHitGifMovie3;
                successHitGifLabel3=nullptr;
                successHitGifMovie3=nullptr;
            }
        });
        qDebug()<<"3号轨道点击";
    }
    else if(n==4){
        if(successHitGifLabel4==nullptr){
            successHitGifLabel4=new QLabel(this);
            successHitGifMovie4 = new QMovie(":/pic/picture/touch.gif");
            successHitGifLabel4->setMovie(successHitGifMovie4);
            successHitGifLabel4->setGeometry(800,570,120,120);
            successHitGifLabel4->setParent(this);
            successHitGifMovie4->start();
            successHitGifLabel4->show();
        }
        connect(successHitGifMovie4,&QMovie::stateChanged,[=](){
            if(successHitGifLabel4!=nullptr&&successHitGifMovie4->state()<2){
                delete successHitGifLabel4;
                delete successHitGifMovie4;
                successHitGifLabel4=nullptr;
                successHitGifMovie4=nullptr;
            }
        });
        qDebug()<<"4号轨道点击";
    }

}

void GameWindow::playGif321(){
    now_mtime-=500;
    wait=4;
    judgment=4;
    if(movie!=nullptr){
        delete movie;
        delete q;
        q=nullptr;
        movie=nullptr;
        music_continue();
        qDebug()<<"321进行删除改变";
    };
    q=new QLabel(this);
    movie = new QMovie(":/pic/picture/time321_once.gif");
    q->setMovie(movie);
    q->setGeometry(260,160,720,405);
    q->setParent(this);
    movie->start();
    timer_321->setInterval(250);
    timer_321->start();
    q->show();
    connect(movie,&QMovie::stateChanged,[=](){
        if(movie!=nullptr&&movie->state()<2){
            delete movie;
            delete q;
            q=nullptr;
            movie=nullptr;
            qDebug()<<"321进行删除改变";
            wait=20;
            judgment=68;
            QTimer::singleShot(10, this,SLOT(music_continue()));
            timer_321->stop();
            //return;
        }
        qDebug()<<"321状态改变";
    });
}
void GameWindow::time321(){
    now_mtime+=250;
    if(now_time-begin_time>=3500){
        receiveTime();
        leftMostJudgmentFunction();
        leftJudgmentFunction();
        rightJudgmentFunction();
        rightMostJudgmentFunction();
    }
}
void GameWindow::playmenu(){
    QLabel *w=new QLabel(this);
    w->setGeometry(0,0,1280,720);
    w->setParent(this);
    w->setStyleSheet("background-color: rgba(0, 0, 0,150);");
    //w->setStyleSheet("background-image: url(:/pic/picture/pausepage.jpg);");
    w->show();

    QLabel *q=new QLabel(this);
    QPixmap *pic = new QPixmap(":/pic/picture/pausepage.jpg");
    q->setPixmap(*pic);
    q->setGeometry(280,150,670,370);
    q->setParent(this);
    //q->setAlignment(Qt::AlignCenter);
    q->show();

    QPushButton *button_continue=new QPushButton(this);
    button_continue->setParent(this);
    button_continue->setText("继续游戏");
    QString btnStyle1 = loadStyle(":/qss/qss/bottom_4.txt");
    //button_continue->setGeometry(540,370,160,60);
    button_continue->setGeometry(470,255,270,82);
    button_continue->setStyleSheet(btnStyle1);
    button_continue->show();


    QPushButton *button_exit=new QPushButton(this);
    button_exit->setParent(this);
    button_exit->setText("退出游戏");
    button_exit->setStyleSheet(btnStyle1);
    button_exit->show();
    button_exit->setGeometry(470,380,270,82);

    connect(button_continue,&QPushButton::clicked,[=](){
        isPause=false;
        delete w;
        delete q;
        delete button_continue;
        delete button_exit;
        playGif321();
        ui->pushButton_5->setChecked(false);
        qDebug()<<"按键按下了";
    });
    connect(button_exit,&QPushButton::clicked,[=](){
        isPause=false;
        gotoEndpage();
    });
//    connect(movie,&QMovie::stateChanged,[=](){
//            delete movie;
//            delete q;
//    });
}
void GameWindow::GameCubeDown(int key,float speed,int key_message,int time){
    //for(int i=0;i++;i<10){
    //timer3->start(100);
    isBegin=false;
    if(key_message==1){
        if(key==0){
            GameShortCube(300,speed);
        }
        else if(key==1){
            GameShortCube(460,speed);
        }
        else if(key==2){
            GameShortCube(620,speed);
        }
        else if(key==3){
            GameShortCube(780,speed);
        };
    }
    else if(key_message==2){
        if(key==0){
            GameLongCube(300,speed,time);
        }
        else if(key==1){
            GameLongCube(460,speed,time);
        }
        else if(key==2){
            GameLongCube(620,speed,time);
        }
        else if(key==3){
            GameLongCube(780,speed,time);
        };
    }
    return;
};
void GameWindow::GameShortCube(int x,float speed){
//    QString r=QString::number(rand()%256);
//    QString g=QString::number(rand()%256);
//    QString b=QString::number(rand()%256);
    QString r="113";
    QString g="30";
    QString b="94";
    list.insertNode();
    qDebug()<<list.n;
    list.setcurrentNode();
    //qDebug()<<list.n;
    list.current->label->setStyleSheet("QLabel{background-color: rgba("+r+", "+g+", "+b+",255);border-width: 1px;border-style: solid;border-color: rgb(255, 255, 255);}");
    list.current->label->setFrameShape (QFrame::Box);


    //q->setText("哈哈哈，鸡汤来咯");
    list.current->label->setGeometry(0,0,160,90);
    list.current->label->setParent(this);
    list.current->label->show();

    ui->label_1->raise();
    ui->pushButton_1->stackUnder(ui->label_1);
    ui->pushButton_1->raise();
    list.current->label->stackUnder(ui->pushButton_1);

    ui->label_2->raise();
    ui->pushButton_2->stackUnder(ui->label_2);
    ui->pushButton_2->raise();
    list.current->label->stackUnder(ui->pushButton_2);

    ui->label_3->raise();
    ui->pushButton_3->stackUnder(ui->label_3);
    ui->pushButton_3->raise();
    list.current->label->stackUnder(ui->pushButton_3);

    ui->label_4->raise();
    ui->pushButton_4->stackUnder(ui->label_4);
    ui->pushButton_4->raise();
    list.current->label->stackUnder(ui->pushButton_4);

    list.current->animation->setTargetObject(list.current->label);
    list.current->flag=1;
    list.current->animation->setPropertyName("pos");
    list.current->animation->setDuration(720/speed);
    list.current->animation->setStartValue(QPoint(x,-90));
    list.current->animation->setEndValue(QPoint(x,630));
    list.current->animation->start();


}


void GameWindow::GameLongCube(int x,float speed,int time){

//    QString r=QString::number(rand()%256);
//    QString g=QString::number(rand()%256);
//    QString b=QString::number(rand()%256);
    QString r="170";
    QString g="170";
    QString b="255";
    list.insertNode();
    qDebug()<<list.n;
    list.setcurrentNode();
    list.current->label->setFrameShape (QFrame::Box);
    list.current->label->setStyleSheet("QLabel{background-color:qlineargradient(spread:pad, x1:0.5, y1:1, x2:0.5, y2:0, stop:0.8 rgba("+r+", "+g+", "+b+",255), stop:1 rgba(255, 255, 255, 0));border-width: 1px;border-style: solid;border-color: rgb(255, 255, 255);}");
    //q->setStyleSheet("QLabel{background-color: rgba("+r+", "+g+", "+b+",175);}");
    //q->setText("哈哈哈，鸡汤来咯");
    float lenth;
    float duration;
    lenth=speed*time;
    duration=(630+lenth)/speed;
    list.current->label->setGeometry(0,0,160,lenth);
    list.current->label->setParent(this);
    list.current->label->show();

    ui->label_1->raise();
    ui->pushButton_1->stackUnder(ui->label_1);
    ui->pushButton_1->raise();
    list.current->label->stackUnder(ui->pushButton_1);


    ui->label_2->raise();
    ui->pushButton_2->stackUnder(ui->label_2);
    ui->pushButton_2->raise();
    list.current->label->stackUnder(ui->pushButton_2);

    ui->label_3->raise();
    ui->pushButton_3->stackUnder(ui->label_3);
    ui->pushButton_3->raise();
    list.current->label->stackUnder(ui->pushButton_3);

    ui->label_4->raise();
    ui->pushButton_4->stackUnder(ui->label_4);
    ui->pushButton_4->raise();
    list.current->label->stackUnder(ui->pushButton_4);

    list.current->animation->setTargetObject(list.current->label);
    list.current->flag=1;
    list.current->animation->setPropertyName("pos");
    list.current->animation->setDuration(duration);
    list.current->animation->setStartValue(QPoint(x,-lenth));
    list.current->animation->setEndValue(QPoint(x,630));
    list.current->animation->start();

};
void GameWindow::keyPressEvent(QKeyEvent *ev){
    if(many1==-1){
        return;
    }
    setFocusPolicy(Qt::StrongFocus);
    int press_key=ev->key();
    if(press_key==leftmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        leftMostPress();
        leftmost_press_time=now_mtime;
    }else if(press_key==left_track){
        if(ev->isAutoRepeat()){
            return;
        }
        leftPress();
        left_press_time=now_mtime;
    }else if(press_key==right_track){
        if(ev->isAutoRepeat()){
            return;
        }
        rightPress();
        right_press_time=now_mtime;
    }else if(press_key==rightmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        rightMostPress();
        rightmost_press_time=now_mtime;
    }
}

void GameWindow::keyReleaseEvent(QKeyEvent *ev){
    if(many1==-1){
        return;
    }
    setFocusPolicy(Qt::StrongFocus);
    int release_key=ev->key();
    if(release_key==leftmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        leftmost_release_time=now_mtime;
        leftMostRelease();
    }else if(release_key==left_track){
        if(ev->isAutoRepeat()){
            return;
        }
        left_release_time=now_mtime;
        leftRelease();
    }else if(release_key==right_track){
        if(ev->isAutoRepeat()){
            return;
        }
        right_release_time=now_mtime;
        rightRelease();
    }else if(release_key==rightmost_track){
        if(ev->isAutoRepeat()){
            return;
        }
        rightmost_release_time=now_mtime;
        rightMostRelease();
    }else if(release_key==Qt::Key_Space){
        pause_time=now_mtime;
        music_pause();
        /*<---------------游戏过程中暂停--------------->*/
    }
}
void GameWindow::time4(){
    now_m+=250;
    now_mtime=now_second+now_m+now_m1;
    if(now_mtime-pause_time>=0){
        qDebug()<<"receiveTime"<<endl;
        receiveTime();
        leftMostJudgmentFunction();
        leftJudgmentFunction();
        rightJudgmentFunction();
        rightMostJudgmentFunction();
    }
    qDebug()<<"250now time:"<<now_mtime<<endl;
}

void GameWindow::time3(){
    now_m=0;
    timer2->stop();
    timer2->setInterval(250);
    timer2->start();
    now_m1+=1000;
    now_mtime=now_second+now_m+now_m1;
    if(now_mtime-pause_time>=0){
        qDebug()<<"receiveTime"<<endl;
        receiveTime();
        leftMostJudgmentFunction();
        leftJudgmentFunction();
        rightJudgmentFunction();
        rightMostJudgmentFunction();
    }
    qDebug()<<"1000now time:"<<now_mtime<<endl;
}

void GameWindow::time2(){
    now_m=0;
    now_m1=0;
    timer2->stop();
    timer1->stop();
    timer2->setInterval(250);
    timer2->start();
    timer1->setInterval(1000);
    timer1->start();
    now_second+=5000;
    now_mtime=now_second;
    receiveTime();
    leftMostJudgmentFunction();
    leftJudgmentFunction();
    rightJudgmentFunction();
    rightMostJudgmentFunction();
    qDebug()<<"5000now_mtime:"<<now_mtime<<endl;
//    if(usage_patterns==1&&many1==0){
//        if(now_second==4000+pause_time){
//            many1++;
//            game_music->play();
//            isPause=false;
//        }
//    }
}

void GameWindow::music_Mess(QString music_mess){
    game_music_name=music_mess;
}

void GameWindow::playGameMusic(QString muname,int pattern){
    ID=this->winId();
    qDebug()<<"ID="<<ID<<endl;
    screen->grabWindow(ID).save("123.jpg",0);
    usage_patterns=pattern;
    /*


            如何确定音乐

    */
    QString system="music_game_data//system//";
    QString player="music_game_data//player//";
    QString music_txt_address;          //地址
    QString music_mp3_address;          //地址
    QString music_wav_address;          //地址
    if(pattern==1)/*游戏模式*/{
            music_mp3_address=player+"music//"+muname+".mp3";
            music_txt_address=player+"file//"+muname+".txt";
    }else{
            qDebug()<<"pattern 模式值错误"<<endl;
            return;
        }
    qDebug()<<"music_mp3_address="<<music_mp3_address<<endl;
    qDebug()<<"music_txt_address="<<music_txt_address<<endl;
    QFile music_message(music_txt_address);     //音乐乐谱文件
    if(!music_message.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "乐谱文件打开失败 Open failed" << endl;
        return;
    }
    QTextStream read(&music_message);
    while(!read.atEnd()){
        music_score+=read.readLine();
    }
    if(pattern==2){
        for(int i=0;i<music_score.size();i++){
            if(music_score[i]!='0'){
                music_score[i]='0';
            }
        }
    }
    qDebug()<<music_score<<endl;
    key_number=0;
    for(int i=0;i<music_score.size();i++){
            if(music_score[i]!='0'){
                key_number++;
            }
        }
    /*<-------------------乐谱读取完毕------------------->*/
    music_message.close();              //关闭乐谱文件
    mpattern=pattern;
    qDebug()<<"start"<<endl;
    game_music=new QMediaPlayer;
    game_music->setMedia(QUrl::fromLocalFile(music_mp3_address));
    qDebug()<<"start2"<<endl;
    game_music->setVolume(music_volume);          //获取控制音量
    //game_music->play();
//    timer->setInterval(1000);
//    timer->start();
    qDebug()<<"start time"<<endl;
}

void GameWindow::playPressMusic(){
//    QSoundEffect press;
//    press.setSource(QUrl::fromLocalFile(".\\resourse\\video\\touch.wav"));
//    press.setLoopCount(1);  //循环次数
//    press.setVolume(1);
//    press.play();

//      QSound music("D:\\QTfile\\test\\resourse\\video\\resourse\\video\\touch2.wav");
//      qDebug()<<"pressSound has been played";
//      music.play();
    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile(".\\resourse\\video\\SFX_Flick.wav"));
    player->setVolume((int)(((float)music_volume)/4));
    player->play();
}

void GameWindow::music_pause(){
    isPause=true;
    game_music->pause();
    timer->stop();
    timer1->stop();
    timer2->stop();
    pause_time=now_mtime;
    begin_time=now_mtime;
    many1=-1;
    playmenu();
    QTimer::singleShot(10, this,SLOT(emitMusicChanged()));
    qDebug()<<"pause pause_time="<<pause_time<<endl;
}

void GameWindow::music_continue(){
    //playGif321();
        qDebug()<<"音乐继续播放1";
        isPause=false;
        now_m=0;
        now_m1=0;
        now_second=begin_time;
        timer->setInterval(5000);
        timer->start();
        timer1->setInterval(1000);
        timer1->start();
        timer2->setInterval(250);
        timer2->start();
        qDebug()<<"音乐继续播放2";
        game_music->play();
        qDebug()<<"音乐继续播放3";
        many1=0;
        QTimer::singleShot(10, this,SLOT(emitMusicChanged()));
        receiveTime();
       leftMostJudgmentFunction();
       leftJudgmentFunction();
       rightJudgmentFunction();
       rightMostJudgmentFunction();

}
void GameWindow::music_exit(){
    game_music->stop();
    many1=0;
}
void GameWindow::receiveTime(){
    if(now_mtime>=0){
        int howlong=0;
        int now=now_mtime/250*4;
        if(music_score[now+wait*4]=='1'){
            GameCubeDown(0,key_speed,1,0);
        }else if(music_score[now+wait*4]=='2'){
            if(music_score[now+wait*4-4]!='2'){
                howlong=0;
                for(int i=0;i<music_score.size();i++){
                    if(music_score[now+wait*4+i*4]=='2'){
                        howlong++;
                    }else{
                        break;
                    }
                }
                GameCubeDown(0,key_speed,2,howlong*250);
            }
        }
        if(music_score[now+wait*4+1]=='1'){
            GameCubeDown(1,key_speed,1,0);
        }else if(music_score[now+wait*4+1]=='2'){
            if(music_score[now+wait*4+1-4]!='2'){
                howlong=0;
                for(int i=0;i<music_score.size();i++){
                    if(music_score[now+wait*4+i*4+1]=='2'){
                        howlong++;
                    }else{
                        break;
                    }
                }
                GameCubeDown(1,key_speed,2,howlong*250);
            }
        }
        if(music_score[now+wait*4+2]=='1'){
            GameCubeDown(2,key_speed,1,0);
        }else if(music_score[now+wait*4+2]=='2'){
            if(music_score[now+wait*4+2-4]!='2'){
                howlong=0;
                for(int i=0;i<music_score.size();i++){
                    if(music_score[now+wait*4+i*4+2]=='2'){
                        howlong++;
                    }else{
                        break;
                    }
                }
                GameCubeDown(2,key_speed,2,howlong*250);
            }
        }
        if(music_score[now+wait*4+3]=='1'){
            GameCubeDown(3,key_speed,1,0);
        }else if(music_score[now+wait*4+3]=='2'){
            if(music_score[now+wait*4+3-4]!='2'){
                howlong=0;
                for(int i=0;i<music_score.size();i++){
                    if(music_score[now+wait*4+i*4+3]=='2'){
                        howlong++;
                    }else{
                        break;
                    }
                }
                GameCubeDown(3,key_speed,2,howlong*250);
            }
        }


    //keyJudgmentFunction();
    }
}

void GameWindow::keyJudgmentFunction(){
    leftMostJudgmentFunction();
}

void GameWindow::leftMostJudgmentFunction(){
    //int judgment=4;
    int judgment_time=now_mtime;
    //qDebug()<<"judgment_time="<<judgment_time<<endl;
    //qDebug()<<"leftmost_score="<<leftmost_score<<endl;
    //qDebug()<<"leftmost_allow_press="<<leftmost_allow_press<<endl;
    //qDebug()<<"leftmost_allow_release="<<leftmost_allow_release<<endl;
    //qDebug()<<"failure_press="<<failure_press<<endl;
    qDebug()<<"success_press="<<success_press<<endl;
    if(leftmost_score==0){
        if(leftmost_allow_release==5&&music_score[judgment_time/250*4+judgment]!=0){
            failure_press++;
            leftmost_allow_press=0;
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(leftmost_allow_release==9){
            leftmost_allow_release=0;
            musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0,judgment_time);
            //leftMostJudgmentFunction();
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(leftmost_allow_press==0){
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment]=='1'){
                leftmost_allow_press=2;
            }if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment]=='2'){
                leftmost_allow_press=2;
            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment]=='1'){
//                leftmost_allow_press=2;
//            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment]=='2'){
//                leftmost_allow_press=2;
//            }
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment]=='0'){
                return;
            }
        }else if(leftmost_allow_press==2){
            if(music_score[judgment_time/250*4+4*jtime2+judgment]=='1'){
                leftmost_allow_press=1;
                leftmost_score=judgment_time/250*4+4*jtime2;
            }
            if(music_score[judgment_time/250*4+4*jtime2+judgment]=='2'&&music_score[judgment_time/250*4+4*(jtime2-1)+judgment]!='2'){
                leftmost_allow_press=10;
                leftmost_score=now_mtime/250*4+4*jtime2;
            }
        }else if(leftmost_allow_press==8){
            leftmost_allow_press=0;
            failure_press++;
            //leftmost_allow_release=5;
        }
        return;
    }else{
        if(leftmost_allow_press==1&&leftmost_allow_release==0){
            if(judgment_time/250*4-leftmost_score>=8){
                //没按
                failure_press++;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0,judgment_time);
                //leftMostJudgmentFunction();
                return;
            }
        }else if(leftmost_allow_press==10&&leftmost_allow_release==0){
            if(judgment_time/250*4-leftmost_score>=4){
                //没按
                failure_press++;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0,judgment_time);
                leftMostJudgmentFunction();
                //return;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==3){
            if(judgment_time/250*4-leftmost_score>=8){
                //没抬
                failure_press++;
                leftmost_allow_release=5;
                leftmost_score=0;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==0){
                //成功
                createSuccessHitGif(1);
                success_press++;
                total_score+=100;
                key1SuccessedPaused=true;
                qDebug()<<"成功,success_press="<<success_press<<endl;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0,judgment_time);
                leftMostJudgmentFunction();
                return;
        }else if(leftmost_allow_press==0&&leftmost_allow_release==4){
            //长按过程中 成功
            createSuccessHitGif(1);
            success_press++;

            total_score+=300;
            key1SuccessedPaused=true;
            if(music_score[judgment_time/250*4+jtime2*4+judgment]=='2'&&music_score[judgment_time/250*4+(jtime2+1)*4+judgment]!='2'){
                leftmost_score=judgment_time/250*4+jtime2*4;
                leftmost_allow_release=3;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==7){
            //长按过程中 提前抬起
            failure_press++;
            leftmost_allow_release=6;
        }else if(leftmost_allow_press==0&&leftmost_allow_release==6){
            //长按过程中 提前抬起
            if(music_score[judgment_time/250*4+judgment]!='2'){
                leftmost_allow_release=0;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0,judgment_time);
                leftMostJudgmentFunction();
                return;
            }
        }
        return;
    }
}

void GameWindow::leftJudgmentFunction(){
    //int judgment=4;
    int judgment_time=now_mtime;
    int function_type=1;
//    qDebug()<<"judgment_time="<<judgment_time<<endl;
//    qDebug()<<"leftmost_score="<<leftmost_score<<endl;
//    qDebug()<<"leftmost_allow_press="<<leftmost_allow_press<<endl;
//    qDebug()<<"leftmost_allow_release="<<leftmost_allow_release<<endl;
//    qDebug()<<"failure_press="<<failure_press<<endl;
//    qDebug()<<"success_press="<<success_press<<endl;
    if(left_score==0){
        if(left_allow_release==5&&music_score[judgment_time/250*4+judgment+function_type]!=0){
            failure_press++;
            left_allow_press=0;
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(left_allow_release==9){
            left_allow_release=0;
            musicScoreAssignValue(&left_allow_press,&left_score,function_type,judgment_time);
            //leftMostJudgmentFunction();
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(left_allow_press==0){
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='1'){
                left_allow_press=2;
            }if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='2'){
                left_allow_press=2;
            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='1'){
//                left_allow_press=2;
//            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='2'){
//                left_allow_press=2;
//            }
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='0'){
                return;
            }
        }else if(left_allow_press==2){
            if(music_score[judgment_time/250*4+4*jtime2+judgment+function_type]=='1'){
                left_allow_press=1;
                left_score=judgment_time/250*4+4*jtime2;
            }
            if(music_score[function_type+judgment_time/250*4+4*jtime2+judgment]=='2'&&music_score[judgment_time/250*4+4*(jtime2-1)+judgment+function_type]!='2'){
                left_allow_press=10;
                left_score=now_mtime/250*4+4*jtime2;
            }
        }else if(left_allow_press==8){
            left_allow_press=0;
            failure_press++;
            //left_allow_release=5;
        }
        return;
    }else{
        if(left_allow_press==1&&left_allow_release==0){
            if(judgment_time/250*4-left_score>=8){
                //没按
                failure_press++;
                musicScoreAssignValue(&left_allow_press,&left_score,function_type,judgment_time);
                //leftJudgmentFunction();
                return;
            }
        }else if(left_allow_press==10&&left_allow_release==0){
            if(judgment_time/250*4-left_score>=4){
                //没按
                failure_press++;
                musicScoreAssignValue(&left_allow_press,&left_score,function_type,judgment_time);
                leftJudgmentFunction();
                //return;
            }
        }else if(left_allow_press==0&&left_allow_release==3){
            if(judgment_time/250*4-left_score>=8){
                //没抬
                failure_press++;
                left_allow_release=5;
                left_score=0;
            }
        }else if(left_allow_press==0&&left_allow_release==0){
                //成功
            createSuccessHitGif(2);

            total_score+=100;
                success_press++;
                qDebug()<<"成功,success_press="<<success_press<<endl;
                musicScoreAssignValue(&left_allow_press,&left_score,function_type,judgment_time);
                leftJudgmentFunction();
                return;
        }else if(left_allow_press==0&&left_allow_release==4){
            //长按过程中 成功
            createSuccessHitGif(2);

            total_score+=300;
            success_press++;
            if(music_score[judgment_time/250*4+jtime2*4+judgment+function_type]=='2'&&music_score[judgment_time/250*4+(jtime2+1)*4+judgment+function_type]!='2'){
                left_score=judgment_time/250*4+jtime2*4;
                left_allow_release=3;
            }
        }else if(left_allow_press==0&&left_allow_release==7){
            //长按过程中 提前抬起
            failure_press++;
            left_allow_release=6;
        }else if(left_allow_press==0&&left_allow_release==6){
            //长按过程中 提前抬起
            if(music_score[judgment_time/250*4+judgment+function_type]!='2'){
                left_allow_release=0;
                musicScoreAssignValue(&left_allow_press,&left_score,function_type,judgment_time);
                leftJudgmentFunction();
                return;
            }
        }
        return;
    }
}

void GameWindow::rightJudgmentFunction(){
    //int judgment=4;
    int judgment_time=now_mtime;
    int function_type=2;
//    qDebug()<<"judgment_time="<<judgment_time<<endl;
//    qDebug()<<"leftmost_score="<<leftmost_score<<endl;
//    qDebug()<<"leftmost_allow_press="<<leftmost_allow_press<<endl;
//    qDebug()<<"leftmost_allow_release="<<leftmost_allow_release<<endl;
//    qDebug()<<"failure_press="<<failure_press<<endl;
//    qDebug()<<"success_press="<<success_press<<endl;
    if(right_score==0){
        if(right_allow_release==5&&music_score[judgment_time/250*4+judgment+function_type]!=0){
            failure_press++;
            right_allow_press=0;
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(right_allow_release==9){
            right_allow_release=0;
            musicScoreAssignValue(&right_allow_press,&right_score,function_type,judgment_time);
            //leftMostJudgmentFunction();
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(right_allow_press==0){
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='1'){
                right_allow_press=2;
            }if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='2'){
                right_allow_press=2;
            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='1'){
//                left_allow_press=2;
//            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='2'){
//                left_allow_press=2;
//            }
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='0'){
                return;
            }
        }else if(right_allow_press==2){
            if(music_score[judgment_time/250*4+4*jtime2+judgment+function_type]=='1'){
                right_allow_press=1;
                right_score=judgment_time/250*4+4*jtime2;
            }
            if(music_score[function_type+judgment_time/250*4+4*jtime2+judgment]=='2'&&music_score[judgment_time/250*4+4*(jtime2-1)+judgment+function_type]!='2'){
                right_allow_press=10;
                right_score=now_mtime/250*4+4*jtime2;
            }
        }else if(right_allow_press==8){
            right_allow_press=0;
            failure_press++;
            //right_allow_release=5;
        }
        return;
    }else{
        if(right_allow_press==1&&right_allow_release==0){
            if(judgment_time/250*4-right_score>=8){
                //没按
                failure_press++;
                musicScoreAssignValue(&right_allow_press,&right_score,function_type,judgment_time);
                //rightJudgmentFunction();
                return;
            }
        }else if(right_allow_press==10&&right_allow_release==0){
            if(judgment_time/250*4-right_score>=4){
                //没按
                failure_press++;
                musicScoreAssignValue(&right_allow_press,&right_score,function_type,judgment_time);
                rightJudgmentFunction();
                //return;
            }
        }else if(right_allow_press==0&&right_allow_release==3){
            if(judgment_time/250*4-right_score>=8){
                //没抬
                failure_press++;
                right_allow_release=5;
                right_score=0;
            }
        }else if(right_allow_press==0&&right_allow_release==0){
                //成功
            createSuccessHitGif(3);
                success_press++;
                total_score+=100;
                qDebug()<<"成功,success_press="<<success_press<<endl;
                musicScoreAssignValue(&right_allow_press,&right_score,function_type,judgment_time);
                rightJudgmentFunction();
                return;
        }else if(right_allow_press==0&&right_allow_release==4){
            //长按过程中 成功
            createSuccessHitGif(3);

            total_score+=300;
            success_press++;
            if(music_score[judgment_time/250*4+jtime2*4+judgment+function_type]=='2'&&music_score[judgment_time/250*4+(jtime2+1)*4+judgment+function_type]!='2'){
                right_score=judgment_time/250*4+jtime2*4;
                right_allow_release=3;
            }
        }else if(right_allow_press==0&&right_allow_release==7){
            //长按过程中 提前抬起
            failure_press++;
            right_allow_release=6;
        }else if(right_allow_press==0&&right_allow_release==6){
            //长按过程中 提前抬起
            if(music_score[judgment_time/250*4+judgment+function_type]!='2'){
                right_allow_release=0;
                musicScoreAssignValue(&right_allow_press,&right_score,function_type,judgment_time);
                rightJudgmentFunction();
                return;
            }
        }
        return;
    }
}

void GameWindow::rightMostJudgmentFunction(){
    //int judgment=4;
    int judgment_time=now_mtime;
    int function_type=3;
//    qDebug()<<"judgment_time="<<judgment_time<<endl;
//    qDebug()<<"leftmost_score="<<leftmost_score<<endl;
//    qDebug()<<"leftmost_allow_press="<<leftmost_allow_press<<endl;
//    qDebug()<<"leftmost_allow_release="<<leftmost_allow_release<<endl;
//    qDebug()<<"failure_press="<<failure_press<<endl;
//    qDebug()<<"success_press="<<success_press<<endl;
    if(rightmost_score==0){
        if(rightmost_allow_release==5&&music_score[judgment_time/250*4+judgment+function_type]!=0){
            failure_press++;
            rightmost_allow_press=0;
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(rightmost_allow_release==9){
            rightmost_allow_release=0;
            musicScoreAssignValue(&rightmost_allow_press,&rightmost_score,function_type,judgment_time);
            //leftMostJudgmentFunction();
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(rightmost_allow_press==0){
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='1'){
                rightmost_allow_press=2;
            }if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='2'){
                rightmost_allow_press=2;
            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='1'){
//                left_allow_press=2;
//            }
//            if(music_score[judgment_time/250*4+4*(jtime1-1+jtime2)+judgment+function_type]=='2'){
//                left_allow_press=2;
//            }
            if(music_score[judgment_time/250*4+4*(jtime1+jtime2-1)+judgment+function_type]=='0'){
                return;
            }
        }else if(rightmost_allow_press==2){
            if(music_score[judgment_time/250*4+4*jtime2+judgment+function_type]=='1'){
                rightmost_allow_press=1;
                rightmost_score=judgment_time/250*4+4*jtime2;
            }
            if(music_score[function_type+judgment_time/250*4+4*jtime2+judgment]=='2'&&music_score[judgment_time/250*4+4*(jtime2-1)+judgment+function_type]!='2'){
                rightmost_allow_press=10;
                rightmost_score=now_mtime/250*4+4*jtime2;
            }
        }else if(rightmost_allow_press==8){
            rightmost_allow_press=0;
            failure_press++;
            //right_allow_release=5;
        }
        return;
    }else{
        if(rightmost_allow_press==1&&rightmost_allow_release==0){
            if(judgment_time/250*4-rightmost_score>=8){
                //没按
                failure_press++;
                musicScoreAssignValue(&rightmost_allow_press,&rightmost_score,function_type,judgment_time);
                //rightJudgmentFunction();
                return;
            }
        }else if(rightmost_allow_press==10&&rightmost_allow_release==0){
            if(judgment_time/250*4-rightmost_score>=4){
                //没按
                failure_press++;
                musicScoreAssignValue(&rightmost_allow_press,&rightmost_score,function_type,judgment_time);
                rightMostJudgmentFunction();
                //return;
            }
        }else if(rightmost_allow_press==0&&rightmost_allow_release==3){
            if(judgment_time/250*4-rightmost_score>=8){
                //没抬
                failure_press++;
                rightmost_allow_release=5;
                rightmost_score=0;
            }
        }else if(rightmost_allow_press==0&&rightmost_allow_release==0){
                //成功

            createSuccessHitGif(4);

            total_score+=100;
                success_press++;
                qDebug()<<"成功,success_press="<<success_press<<endl;
                musicScoreAssignValue(&rightmost_allow_press,&rightmost_score,function_type,judgment_time);
                rightMostJudgmentFunction();
                return;
        }else if(rightmost_allow_press==0&&rightmost_allow_release==4){
            //长按过程中 成功
            createSuccessHitGif(4);
            success_press++;

            total_score+=300;
            if(music_score[judgment_time/250*4+jtime2*4+judgment+function_type]=='2'&&music_score[judgment_time/250*4+(jtime2+1)*4+judgment+function_type]!='2'){
                rightmost_score=judgment_time/250*4+jtime2*4;
                rightmost_allow_release=3;
            }
        }else if(rightmost_allow_press==0&&rightmost_allow_release==7){
            //长按过程中 提前抬起
            failure_press++;
            rightmost_allow_release=6;
        }else if(rightmost_allow_press==0&&rightmost_allow_release==6){
            //长按过程中 提前抬起
            if(music_score[judgment_time/250*4+judgment+function_type]!='2'){
                rightmost_allow_release=0;
                musicScoreAssignValue(&rightmost_allow_press,&rightmost_score,function_type,judgment_time);
                rightMostJudgmentFunction();
                return;
            }
        }
        return;
    }
}

void GameWindow::leftMostPress(){
    //qDebug()<<"press"<<endl;
    playPressMusic();
    ui->pushButton_1->setChecked(true);
    if(leftmost_allow_press==0){
        return;
    }else if(leftmost_allow_press==1){
        leftmost_allow_press=0;
        leftmost_allow_release=3;
        return;
    }else if(leftmost_allow_press==10){
        leftmost_allow_press=0;
        leftmost_allow_release=4;
        return;
    }else if(leftmost_allow_press==2){
        leftmost_allow_press=8;
        leftmost_score=0;
        return;
    }
}

void GameWindow::leftMostRelease(){
    //qDebug()<<"release"<<endl;
    ui->pushButton_1->setChecked(false);
    if(leftmost_allow_release==0){
        return;
    }else if(leftmost_allow_release==3){
        leftmost_allow_release=0;
        leftMostJudgmentFunction();//准确抬起
    }else if(leftmost_allow_release==4){
        leftmost_allow_release=7;
        leftMostJudgmentFunction();//长按时提前抬起
    }else if(leftmost_allow_release==5){
        leftmost_allow_release=9;//一直长按的抬起
        leftMostJudgmentFunction();
    }
}

void GameWindow::leftPress(){
    playPressMusic();
    ui->pushButton_2->setChecked(true);
    //qDebug()<<"press"<<endl;
    if(left_allow_press==0){
        return;
    }else if(left_allow_press==1){
        left_allow_press=0;
        left_allow_release=3;
        return;
    }else if(left_allow_press==10){
        left_allow_press=0;
        left_allow_release=4;
        return;
    }else if(left_allow_press==2){
        left_allow_press=8;
        left_score=0;
        return;
    }
}

void GameWindow::rightPress(){
    //qDebug()<<"press"<<endl;
    playPressMusic();
    ui->pushButton_3->setChecked(true);
    if(right_allow_press==0){
        return;
    }else if(right_allow_press==1){
        right_allow_press=0;
        right_allow_release=3;
        return;
    }else if(right_allow_press==10){
        right_allow_press=0;
        right_allow_release=4;
        return;
    }else if(right_allow_press==2){
        right_allow_press=8;
        right_score=0;
        return;
    }
}

void GameWindow::rightMostPress(){
    //qDebug()<<"press"<<endl;
    playPressMusic();
    ui->pushButton_4->setChecked(true);
    if(rightmost_allow_press==0){
        return;
    }else if(rightmost_allow_press==1){
        rightmost_allow_press=0;
        rightmost_allow_release=3;
        return;
    }else if(rightmost_allow_press==10){
        rightmost_allow_press=0;
        rightmost_allow_release=4;
        return;
    }else if(rightmost_allow_press==2){
        rightmost_allow_press=8;
        rightmost_score=0;
        return;
    }
}

void GameWindow::leftRelease(){
    //qDebug()<<"release"<<endl;
    ui->pushButton_2->setChecked(false);
    if(left_allow_release==0){
        return;
    }else if(left_allow_release==3){
        left_allow_release=0;
        leftJudgmentFunction();//准确抬起
    }else if(left_allow_release==4){
        left_allow_release=7;
        leftJudgmentFunction();//长按时提前抬起
    }else if(left_allow_release==5){
        left_allow_release=9;//一直长按的抬起
        leftJudgmentFunction();
    }
}

void GameWindow::rightRelease(){
    //qDebug()<<"release"<<endl;
    ui->pushButton_3->setChecked(false);
    if(right_allow_release==0){
        return;
    }else if(right_allow_release==3){
        right_allow_release=0;
        rightJudgmentFunction();//准确抬起
    }else if(right_allow_release==4){
        right_allow_release=7;
        rightJudgmentFunction();//长按时提前抬起
    }else if(right_allow_release==5){
        right_allow_release=9;//一直长按的抬起
        rightJudgmentFunction();
    }
}

void GameWindow::rightMostRelease(){
    //qDebug()<<"release"<<endl;
    ui->pushButton_4->setChecked(false);
    if(rightmost_allow_release==0){
        return;
    }else if(rightmost_allow_release==3){
        rightmost_allow_release=0;
        rightMostJudgmentFunction();//准确抬起
    }else if(rightmost_allow_release==4){
        rightmost_allow_release=7;
        rightMostJudgmentFunction();//长按时提前抬起
    }else if(rightmost_allow_release==5){
        rightmost_allow_release=9;//一直长按的抬起
        rightMostJudgmentFunction();
    }
}

void GameWindow::musicScoreAssignValue(int *press,int *score,int type,int judgment_time){
    int judgment=4;
    if(music_score[judgment_time/250*4+type+judgment]=='1'&&judgment_time/250*4!=*score){
        *press=1;
        *score=judgment_time/250*4;
    }else if(music_score[judgment_time/250*4+type+judgment]=='2'&&judgment_time/250*4!=*score){
        *press=10;
        *score=judgment_time/250*4;
        /*<------------判断乐谱当前位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[judgment_time/250*4+4*(jtime2-1)+type+judgment]=='1'&&judgment_time/250*4+4*(jtime2-1)!=*score){
        *press=1;
        *score=judgment_time/250*4+4*(jtime2-1);
    }else if(music_score[judgment_time/250*4+4*(jtime2-1)+type+judgment]=='2'&&judgment_time/250*4+4*(jtime2-1)!=*score){
        *press=10;
        *score=judgment_time/250*4+4*(jtime2-1);
        /*<------------判断乐谱下一行位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[judgment_time/250*4+4*jtime2+type+judgment]=='1'&&judgment_time/250*4+4*jtime2!=*score){
        *press=1;
        *score=judgment_time/250*4+4*jtime2;
    }else if(music_score[judgment_time/250*4+4*jtime2+type+judgment]=='2'&&judgment_time/250*4+4*jtime2!=*score){
        *press=10;
        *score=judgment_time/250*4+4*jtime2;
        /*<------------判断当前乐谱下下一行位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[judgment_time/250*4+4*(1+jtime2)+type+judgment]=='1'&&judgment_time/250*4+4*(1+jtime2)!=*score){
        *press=2;
        *score=0;
    }else if(music_score[judgment_time/250*4+4*(1+jtime2)+type+judgment]=='2'&&judgment_time/250*4+4*(1+jtime2)!=*score){
        *press=2;
        *score=0;
        /*<------------判断当前乐谱下下下一行位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[now_mtime/250*4+4*(1+jtime2)+type+judgment]=='0'&&now_mtime/250*4+4*(1+jtime2)!=*score){
        *press=0;
        *score=0;
    }
    return;
}


void GameWindow::on_pushButton_5_clicked()
{
    music_pause();
    if(q!=nullptr){
        delete q;
        delete movie;
        q=nullptr;
        movie=nullptr;
    };
}




