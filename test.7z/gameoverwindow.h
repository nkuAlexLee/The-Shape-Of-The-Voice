#ifndef GAMEOVERWINDOW_H
#define GAMEOVERWINDOW_H

#include <QWidget>
#include <QGuiApplication>
#include <QScreen>
#include <QFile>
#include<QDebug>
namespace Ui {
class GameOverWindow;
}

class GameOverWindow : public QWidget
{
    Q_OBJECT

public:
    explicit GameOverWindow(QWidget *parent = nullptr,float finishnumber=0,int successPress=0,int scorenumber=0,QString filename="");
    ~GameOverWindow();
    void *p;
    float finished=0;
    int success_press=0;
    int total_score=0;
    QString strfinished;
    QString strsuccess_press;
    QString strscore;
    QString strfilename;
    QString substring(QString str,int left,int right){
        QString restr="";
        for(int i=left-1;i<right;i++){
            restr+=str[i];
        }
        return restr;
    }

    int readHighScore(QString musicname,int score,int type){
        int highscore=1;
        int l=musicname.size();
        QString address=".\\music_game_data\\system\\music\\musicHighScore.txt";/*<-------------文件地址------------->*/
        QString message="";
        QString strscore;
        if(type==0){
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                message=read.readLine();
                if(musicname==substring(message,1,l)){
                    strscore=substring(message,l+1,message.size()-1);
                    break;
                }
            }while(!read.atEnd());
            highscore=strscore.toInt();
            music_score_txt.close();
            return highscore;
        }else if(type==1){
            int m=0;
            QString s = QString("%1").arg(score),s11;
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "乐谱文件打开失败 Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                s11=read.readLine();
                qDebug()<<"substring="<<substring(s11,1,l)<<endl;
                if(musicname==substring(s11,1,l)){
                    strscore=substring(s11,l+1,s11.size()-1);
                    highscore=strscore.toInt();
                    qDebug()<<"strscore="<<strscore<<endl;
                    qDebug()<<"highscore="<<highscore<<endl;
                    qDebug()<<"score="<<score<<endl;
                    if(highscore<score){
                        message+=musicname+s+"$";
                        m++;
                        continue;
                    }else{
                        m++;
                    }
                }
                message+=s11;
            }while(!read.atEnd());
            music_score_txt.close();
            if(m==0){
               message+=musicname+s+"$";
            }
            if(!music_score_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            QTextStream txtOutput(&music_score_txt);
            QString s1="";
                    for(int i=0;i<message.size();i++){
                        if(message[i]=='$'){
                            s1+=message[i]+"\n";
                        }else{
                            s1+=message[i];
                        }
                    }
                    txtOutput << s1 << endl;
                    music_score_txt.close();
        return 1;
        }
        return 0;
    }

    float readHighFinished(QString musicname,float finish,int type){
        int highfinish=1;
        int l=musicname.size();
        QString address=".\\music_game_data\\system\\music\\musicHighFinished.txt";/*<-------------文件地址------------->*/
        QString message="";
        QString strfinish;
        if(type==0){
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                message=read.readLine();
                if(musicname==substring(message,1,l)){
                    strfinish=substring(message,l+1,message.size()-1);
                    break;
                }
            }while(!read.atEnd());
            highfinish=strfinish.toFloat();
            music_score_txt.close();
            return highfinish;
        }else if(type==1){
            int m=0;
            QString s = QString("%1").arg(finish),s11;
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "文件打开失败 Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                s11=read.readLine();
                if(musicname==substring(s11,1,l)){
                    strfinish=substring(s11,l+1,s11.size()-1);
                    highfinish=strfinish.toFloat();
                    qDebug()<<"strscore="<<strfinish<<endl;
                    qDebug()<<"highfinish="<<highfinish<<endl;
                    qDebug()<<"finish="<<finish<<endl;
                    if(highfinish<finish){
                        message+=musicname+s+"$";
                        m++;
                        continue;
                    }else{
                        m++;
                    }
                }
                message+=s11;
            }while(!read.atEnd());
            music_score_txt.close();
            if(m==0){
               message+=musicname+s+"$";
            }
            if(!music_score_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            QTextStream txtOutput(&music_score_txt);
            QString s1="";
                    for(int i=0;i<message.size();i++){
                        if(message[i]=='$'){
                            s1+=message[i]+"\n";
                        }else{
                            s1+=message[i];
                        }
                    }
                    txtOutput << s1 << endl;
                    music_score_txt.close();
        return 1;
        }
        return 0;
    }

public slots:
    void screenShots();
private slots:

    void on_backpushButton_clicked();

    void on_screenshotbackpushButton_pressed();

    void on_screenshotbackpushButton_released();

private:
    Ui::GameOverWindow *ui;
};

#endif // GAMEOVERWINDOW_H
