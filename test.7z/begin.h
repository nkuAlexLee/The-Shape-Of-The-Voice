#ifndef BEGIN_H
#define BEGIN_H

#include <QWidget>
#include<QMediaPlayer>
#include<QMediaPlaylist>
#include<QLabel>
#include<QMovie>
#include<QFile>
namespace Ui {
class Begin;
}

class Begin : public QWidget
{
    Q_OBJECT

public:
    explicit Begin(QWidget *parent = nullptr);
    //~Begin();
    QMediaPlayer *player = new QMediaPlayer(this);
    QMediaPlaylist *medialist=new QMediaPlaylist(this);
    QMediaPlaylist *musiclist=new QMediaPlaylist(this);
    QMediaPlayer *backgroundmusic=new QMediaPlayer(this);
    QLabel* transq=nullptr;
    QMovie* transmovie=nullptr;
    void playInterimgif2(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/begin.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };
    QString substring(QString str,int left,int right){
        QString restr="";
        for(int i=left-1;i<right;i++){
            restr+=str[i];
        }
        return restr;
    }

    int readKey(int where,int key_ascii,int type){
        int key=0;
        QString address=".\\music_game_data\\system\\music\\keySetting.txt";/*<-------------文件地址------------->*/
        QString message,mess;
        QFile key_ascii_txt(address);
        if(!key_ascii_txt.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            qDebug() << "Open failed" << endl;
            return 0;
        }
        QTextStream read(&key_ascii_txt);
        do{
            message=read.readLine();
            qDebug()<<"message:"<<message;
        }while(!read.atEnd());
        if(type==0){
//            mess=message[where];
//            qDebug()<<"mess:"<<mess;
            QByteArray array=message.toLatin1();
            key=(int)array.at(where);
            qDebug()<<"key:"<<key;
            key_ascii_txt.close();
        }else if(type==1){
            key_ascii_txt.close();
            message[where]=(char)key_ascii;
            qDebug()<<"mess:"<<mess;
            QTextStream txtOutput(&key_ascii_txt);
            if(!key_ascii_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
            }
            txtOutput << message ;
            key_ascii_txt.close();
        }
        return key;
    }

    int readGameMusic(int volume,int type){
        int musicvolume=50;
        QString address=".\\music_game_data\\system\\music\\gamemusicVolume.txt";/*<-------------文件地址------------->*/
        QString message,mess;
        QFile GameMusic_txt(address);
        if(!GameMusic_txt.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            qDebug() << "Open failed" << endl;
            return 50;
        }
        QTextStream read(&GameMusic_txt);
        do{
            message=read.readLine();
            qDebug()<<"message:"<<message;
        }while(!read.atEnd());
        if(type==0){
            musicvolume=message.toInt();
            GameMusic_txt.close();
        }
        else if(type==1){
            GameMusic_txt.close();
            message= QString("%1").arg(volume);
            QTextStream txtOutput(&GameMusic_txt);
            if(!GameMusic_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            txtOutput << message;
            GameMusic_txt.close();
        }
        return musicvolume;
    }


    int readBackGroundMusic(int volume,int type){
        int musicvolume=50;
        QString address=".\\music_game_data\\system\\music\\backgroundmusicVolume.txt";/*<-------------文件地址------------->*/
        QString message,mess;
            QFile BackGroundMusic(address);
            if(!BackGroundMusic.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "Open failed" << endl;
                return 0;
            }
            QTextStream read(&BackGroundMusic);
            do{
                message=read.readLine();
                qDebug()<<"message:"<<message;
            }while(!read.atEnd());
        if(type==0){
            musicvolume=message.toInt();
            BackGroundMusic.close();
        }else if(type==1){
            BackGroundMusic.close();
            message= QString("%1").arg(volume);
            QTextStream txtOutput(&BackGroundMusic);
            if(!BackGroundMusic.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            txtOutput << message ;
            BackGroundMusic.close();
        }
        return musicvolume;
    }


private:
    Ui::Begin *ui;
};

#endif // BEGIN_H
