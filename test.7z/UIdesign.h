#ifndef UIDESIGN_H
#define UIDESIGN_H
#include"digitalzoom.h"
#include"settingwindow.h"
#include"notationwindow.h"
#include"mainwindow.h"
#include"selectmusicwindow.h"

class Draw:public QWidget
{
public:
    QImage *image=nullptr;
    QLabel *q=nullptr;
    QMovie *movie=nullptr;
    explicit Draw(QWidget *parent = nullptr);
    ~Draw(){};
    static QString loadStyle(QString const website){
        QString qss;
        QFile qssFile(website);
        qssFile.open(QFile::ReadOnly);
        if(qssFile.isOpen())
        {
            qss = QLatin1String(qssFile.readAll());
            qssFile.close();
        }
        return qss;
    };
    static void gameTitle(DigitalZoom*m_digitalZoomWidget)
        {
        QImage image=QImage(":/pic/picture/mainpage.png");
        QPixmap pixmap=QPixmap();
        pixmap.convertFromImage(image);
        QLabel*label=new QLabel(m_digitalZoomWidget);/*
        label->setAttribute(Qt::WA_TranslucentBackground);
        label->setWindowFlags(Qt::FramelessWindowHint | Qt::Tool);*/
        label->setGeometry(0,0,1280,720);
        //label->setVisible (false);
        label->setPixmap(pixmap);
        }

    static void gameBottom(DigitalZoom*m_digitalZoomWidget){
            QPushButton*m_registerAccountBtn1 = new QPushButton(m_digitalZoomWidget);
            //m_registerAccountBtn->resize(80, 30);
            m_registerAccountBtn1->setGeometry(180,120,480,140);
            m_registerAccountBtn1->setFlat(true);
            m_registerAccountBtn1->setText("开始游戏      ");
            QString btnStyle1 = loadStyle(":/qss/qss/bottom_1.txt");
            m_registerAccountBtn1->setStyleSheet(btnStyle1);
            connect(m_registerAccountBtn1,&QPushButton::clicked,[=](){
                //playInterimgif1(m_digitalZoomWidget);
                m_digitalZoomWidget->close();
                SelectMusicWindow *s=new SelectMusicWindow();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->close();
                //((MainWindow*)(m_digitalZoomWidget->mainPtr))->backgroundMusic->stop();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->player->stop();
                s->playInterimgif2();
                s->show();
                s->p=m_digitalZoomWidget->mainPtr;
            });


            QPushButton*m_registerAccountBtn2 = new QPushButton(m_digitalZoomWidget);
            //m_registerAccountBtn->resize(80, 30);
            m_registerAccountBtn2->setGeometry(120,260,480,140);
            m_registerAccountBtn2->setFlat(true);
            m_registerAccountBtn2->setText("录入曲谱      ");
            QString btnStyle2 = loadStyle(":/qss/qss/bottom_2.txt");
            m_registerAccountBtn2->setStyleSheet(btnStyle2);
            connect(m_registerAccountBtn2,&QPushButton::clicked,[=](){
                m_digitalZoomWidget->close();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->close();
                //((MainWindow*)(m_digitalZoomWidget->mainPtr))->backgroundMusic->stop();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->player->stop();
                NotationWindow *n=new NotationWindow();
                n->playInterimgif2();
                n->show();
                n->p=m_digitalZoomWidget->mainPtr;
            });

            QPushButton*m_registerAccountBtn3 = new QPushButton(m_digitalZoomWidget);
            //m_registerAccountBtn->resize(80, 30);
            m_registerAccountBtn3->setGeometry(170,390,480,140);
            m_registerAccountBtn3->setFlat(true);
            m_registerAccountBtn3->setText("游戏设置      ");
            QString btnStyle3 = loadStyle(":/qss/qss/bottom_3.txt");
            m_registerAccountBtn3->setStyleSheet(btnStyle3);
            connect(m_registerAccountBtn3,&QPushButton::clicked,[=](){
                m_digitalZoomWidget->close();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->close();
                //((MainWindow*)(m_digitalZoomWidget->mainPtr))->backgroundMusic->stop();
                ((MainWindow*)(m_digitalZoomWidget->mainPtr))->player->stop();
                settingwindow *s=new settingwindow();
                s->playInterimgif2();
                s->show();
                s->p=m_digitalZoomWidget->mainPtr;

            });
};
};


#endif // UIDESIGN_H
