#ifndef GAMERUNNING_H
#define GAMERUNNING_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class GameRunning : public QWidget
{

    Q_OBJECT

public:

    explicit GameRunning(QWidget *parent = nullptr);
    void coreMusicGame(QString musicname,int pattern);
    QString music_tx="";
    QString music_txt_address;          //地址
    QString music_score="";             //乐谱



    int determine_time;                 //判定的半时长
    int mpattern=0;
    int wait=7;                         //手动改，延迟倍数
    int now_ptime=0;                    //当前游戏时间
    int key_number=0;                   //按键数量
    int success_press=0;                //成功击打
    int total_score=0;                  //总得分
    int failure_press=0;                //失败击打
    double completion=0.0;              //完成百分比
    int jtime1=2,jtime2=2;

    int leftmost_allow_press=0;     //0:不做如何处理,1：允许按压,2：禁止按压
    int leftmost_allow_release=0;   //3:允许抬起,4：长按过程中，禁止抬起
    int left_allow_press=0;         //5：禁止抬起
    int left_allow_release=0;       //（一直按着没有抬起来，
    int right_allow_press=0;        //乐谱由0变为1或者2，此时读到5，失败+1）
    int right_allow_release=0;      //6：长按过程中，抬起之后
    int rightmost_allow_press=0;    //7：长按过程中，抬起来了
    int rightmost_allow_release=0;  //8:在等于2的时候按压,9:5的时候抬起

    int leftmost_score=0;           //最左侧轨道下一个按键的位置
    int left_score=0;
    int right_score=0;
    int rightmost_score=0;
    /*<--------------------按键判定函数-------------------->*/
    void keyJudgmentFunction();
    void leftMostJudgmentFunction();
    void leftJudgmentFunction();
    void rightJudgmentFunction();
    void rightMostJudgmentFunction();
    void musicScoreAssignValue(int *press,int *score,int type);
    /*<--------------------按键判定函数-------------------->*/
signals:

public slots:

    void beginRun();
    void leftMostSlot(int ptime,int rtime);//获得最左侧键盘信号后执行的任务
    void leftSlot(int ptime,int rtime);
    void rightSlot(int ptime,int rtime);
    void rightMostSlot(int ptime,int rtime);
    void musicMess(QString musicmess,int pattern);  //音乐信息
    void musicEnd();                                //音乐结束播放
    void receiveTime(int time);                     //获得当前游戏时间
    /*<------------------游戏模式传递按键信息------------------>*/
        void leftMostPress();
        void leftPress();
        void rightPress();
        void rightMostPress();
        void leftMostRelease();
        void leftRelease();
        void rightRelease();
        void rightMostRelease();
    /*<------------------游戏模式传递按键信息------------------>*/


};

#endif // GAMERUNNING_H
