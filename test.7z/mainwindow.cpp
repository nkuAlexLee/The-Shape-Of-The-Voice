#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "UIdesign.h"
#include"GlobalData2.h"
MainWindow::MainWindow(QWidget *parent,QMediaPlayer *mediaplayer,QMediaPlaylist *mediaplaylist,QMediaPlayer *backgroundmusic,QMediaPlaylist *musicplaylist): QMainWindow(parent), ui(new Ui::MainWindow)
{

    //parent->close();
    MainWindow::mainPtr=this;
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    //setWindowFlags(Qt::WindowStaysOnTopHint);
    setFixedSize(this->width(), this->height());
    m_digitalZoomWidget = new DigitalZoom(this);
    m_digitalZoomWidget->mainPtr=MainWindow::mainPtr;
    m_digitalZoomWidget->set(Draw::gameTitle);
    m_digitalZoomWidget->set(Draw::gameBottom);

    backgroundMusic=backgroundmusic;
    player=mediaplayer;
    medialist=mediaplaylist;
    musiclist=musicplaylist;
    //播放视频
    player->setVideoOutput(ui->Video_Widget);
    player->setPlaylist(medialist);
    medialist->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    this->setCentralWidget(ui->Video_Widget);
    ui->Video_Widget->show();
    player->play();
    backgroundMusic->setVolume(backgroundmusic_volume);
    backgroundMusic->play();

    while(player->state()!=QMediaPlayer::PlayingState){};

}

MainWindow::~MainWindow()
{

    delete m_digitalZoomWidget;
    delete ui;
    delete player;
    delete medialist;

}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    m_digitalZoomWidget->resize(width(),height());
}

void MainWindow::moveEvent(QMoveEvent *event)
{
    m_digitalZoomWidget->move(geometry().x(),geometry().y());
}

