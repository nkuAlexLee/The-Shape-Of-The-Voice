#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QWidget>
#include <QMediaPlayer>
#include <QLabel>
#include <QPropertyAnimation>
#include <QGuiApplication>
#include"LinkedList.h"
#include"gameoverwindow.h"
#include <QSoundEffect>
namespace Ui {
class GameWindow;
}

class GameWindow : public QWidget
{
    Q_OBJECT

public:
    explicit GameWindow(QWidget *parent,QString filename);
    ~GameWindow();
    void music_change();
    void playGif321();
    void playmenu();
    void receiveTime();
    void keyPressEvent(QKeyEvent *ev);
    void keyReleaseEvent(QKeyEvent *ev);
    void playGameMusic(QString muname,int pattern);
    void musicScoreAssignValue(int *press,int *score,int type,int judgment_time);
    QString loadStyle(QString const website);
    void Begin();
    void playGreat();
    void playPressMusic();
    void playFinished();
    void createSuccessHitGif(int n);
    void deleteptr();
    void *p;
    void gotoEndpage();
    ListNodeClass list;
    QLabel *w=nullptr;
    QLabel *q=nullptr;
    QMovie *movie=nullptr;
    QLabel *successHitGifLabel1=nullptr;
    QMovie *successHitGifMovie1=nullptr;
    QLabel *successHitGifLabel2=nullptr;
    QMovie *successHitGifMovie2=nullptr;
    QLabel *successHitGifLabel3=nullptr;
    QMovie *successHitGifMovie3=nullptr;
    QLabel *successHitGifLabel4=nullptr;
    QMovie *successHitGifMovie4=nullptr;
    QLabel *w2=nullptr;
    QLabel *q2=nullptr;
    QMovie *movie2=nullptr;
    QSoundEffect *press=nullptr;


    int isBegin;
    int begin_time=0;
    QString filename;
    QString music_tx;
    //GameRunning* run;
    QString music_txt_address;          //地址
    QString music_score="";             //乐谱
    QMediaPlayer *game_music;
    QString system="music_game_data//system//";
    QString player="music_game_data//player//";
    //地址
    QString music_mp3_address;          //地址
    QString music_wav_address;          //地址

    QScreen *screen = QGuiApplication::primaryScreen();
    QString strfinished=QString::number(finished)+"%";
    QString strsuccess_press=QString::number(success_press);
    QString strscore=QString::number(total_score);
    float finished;
    int ID=0;
    int judgment=0;
    bool isPause=false;
    bool key1SuccessedPaused=false;
    bool key2SuccessedPaused=false;
    bool key3SuccessedPaused=false;
    bool key4SuccessedPaused=false;
    int pause_time=0;
    int mpattern=0;
    int key=0;                          //哪个轨道，调用使用
    int key_message=0;                  //谱子的0，1，2
    float key_speed=0.675;                 //单位毫秒
    int many1=0;
    int now_mtime=0;                    //音乐当前的时间
    int now_m=0;
    int now_m1=0;
    int now_second=0;
    int leftmost_press_time=0;
    int leftmost_release_time=0;
    int left_press_time=0;
    int left_release_time=0;
    int right_press_time=0;
    int right_release_time=0;
    int rightmost_press_time=0;
    int rightmost_release_time=0;
    int wait=4;
    QString game_music_name="";
    QTimer *timer,*timer1,*timer2,*timer3,*timer_321;
    void GameCubeDown(int key,float speed,int key_message,int time);
    void GameShortCube(int x,float speed);
    void GameLongCube(int x,float speed,int time);//speed的单位是px/ms
    void musicMess(QString musicmess,int pattern);
    /*<--------------------按键判定函数-------------------->*/
    void keyJudgmentFunction();
    void leftMostJudgmentFunction();
    void leftJudgmentFunction();
    void rightJudgmentFunction();
    void rightMostJudgmentFunction();
    /*<--------------------按键判定函数-------------------->*/
    int key_number=1;                   //按键数量
    int success_press=0;                //成功击打
    int total_score=0;                  //总得分
    int failure_press=0;                //失败击打
    double completion=0.0;              //完成百分比
    int jtime1=2,jtime2=2;

    int leftmost_allow_press=0;     //0:不做如何处理,1：允许按压,2：禁止按压,10:长按允许按压
    int leftmost_allow_release=0;   //3:允许抬起,4：长按过程中，禁止抬起
    int left_allow_press=0;         //5：禁止抬起
    int left_allow_release=0;       //（一直按着没有抬起来，
    int right_allow_press=0;        //乐谱由0变为1或者2，此时读到5，失败+1）
    int right_allow_release=0;      //6：长按过程中，抬起之后
    int rightmost_allow_press=0;    //7：长按过程中，抬起来了
    int rightmost_allow_release=0;  //8:在等于2的时候按压,9:5的时候抬起

    int leftmost_score=0;           //最左侧轨道下一个按键的位置
    int left_score=0;
    int right_score=0;
    int rightmost_score=0;
//public slots:
//    void GameCubeDown(int key,float speed,int key_message,int time);
//    void GameShortCube(int x,float speed);
//    void GameLongCube(int x,float speed,int time);//speed的单位是px/ms
    /*<------------------游戏模式传递按键信息------------------>*/
        void leftMostPress();
        void leftPress();
        void rightPress();
        void rightMostPress();
        void leftMostRelease();
        void leftRelease();
        void rightRelease();
        void rightMostRelease();
    /*<------------------游戏模式传递按键信息------------------>*/

private:
    Ui::GameWindow *ui;
signals:
     bool playFinishedChanged();
     bool MusicChanged();
public slots:
    void time2();
    void time3();
    void time4();
    void time321();
    void music_Mess(QString music_mess);
    void music_pause();
    void music_continue();
    void music_exit();
    void emitplayFinishedChanged(){
        emit playFinishedChanged();
    }
    void emitMusicChanged(){
        emit MusicChanged();
    }
private slots:
    void on_pushButton_5_clicked();

};

#endif // GAMEWINDOW_H
