#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "digitalzoom.h"
#include "settingwindow.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    void *mainPtr;
    MainWindow(QWidget *parent = nullptr,QMediaPlayer *mediaplayer= nullptr,QMediaPlaylist *mediaplaylist= nullptr,QMediaPlayer *backgroundmusic=nullptr,QMediaPlaylist *musicplaylist= nullptr);
    QMediaPlayer *player;
    QMediaPlaylist *medialist;
    QMediaPlayer *backgroundMusic;
    QMediaPlaylist *musiclist;
    void showUI();
    ~MainWindow();
    DigitalZoom* m_digitalZoomWidget;

protected:
    void resizeEvent(QResizeEvent *event) override;
    void moveEvent(QMoveEvent *event) override;

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
