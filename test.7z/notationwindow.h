#ifndef NOTATIONWINDOW_H
#define NOTATIONWINDOW_H

#include <QWidget>
#include<QMediaPlayer>
#include<QFileDialog>
#include<QLabel>
#include<QMovie>
#include <QLine>
#include<QIcon>
#include <fstream>
#include <QTime>
#include <stack>
#include <QFile>
namespace Ui {
class NotationWindow;
}

using namespace std;

const int Tot_knot = 1200;

struct Node{
    int press;
    Node * next;
};
class NotationWindow : public QWidget
{
    Q_OBJECT

public:
    explicit NotationWindow(QWidget *parent = nullptr);
    ~NotationWindow();

    void musicPositionChange(qint64 position);
    QString formatTime(int ms);
    void slotBtnClick();
    void setBtn();
    void initStave();
    void get_stave();
    void goToOtherPage();
    void *p;
    bool musicPositionChangeFlag = false;
    bool musicPlayed=true;
    QMediaPlayer *player=nullptr;
    QLabel* transq=nullptr;
    QMovie* transmovie=nullptr;
    void fileEmpty(const string fileName);
    const char* nowPash;
    bool isRead=false;
    void playInterimgif1(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim1.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
    };
    void playInterimgif2(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim2.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };

private slots:
    void on_BackButtom_clicked();
        void on_BackButtom_4_clicked();
        //void setSliderValue();
        void on_horizontalSlider_valueChanged(int value);
        //void updateTimeLine(qint64 position);

        void on_horizontalSlider_sliderPressed();

        void on_horizontalSlider_sliderReleased();

        void on_pushButton_3_clicked();

        void change_off_line(int x,int y);

         void re_write_stave(ofstream *);

         void scrollPositionChange();


         void on_shortknock_clicked();

         void on_longknock_clicked();

         void on_longknock_2_clicked();

         void on_pushButton_clicked();

         void keyPressEvent(QKeyEvent *ev);
         void keyReleaseEvent(QKeyEvent *ev);
         void init_key_signal();

         void imitate_short_click(int y);
         void imitate_long_click(int y);
         void cancel_imitate_click(int y);

         void on_BackButtom_3_clicked();
         string QString_to_String(QString q_s);

         void scroll_slider_change(int val);

         //void check_time_change();

         void on_horizontalSlider_sliderMoved(int position);


         void on_BackButtom_2_clicked();

private:
    Ui::NotationWindow *ui;
    int btn_state[4][Tot_knot];     //按钮状态（无/短按/长按）
        int CNT_STAVE_ROW = -1;              //记录乐谱多少行
        int NOW_STATE = 1;              //当前点击状态
        int NOW_SCRO_POS = 0;           //当前scrobar位置
        QPushButton *btn[4][Tot_knot];  //按钮
        QIcon ic_1;
        QIcon ic_2;
        QIcon ic_3;
        QTimer *timer=nullptr;
        QTimer *tim=nullptr;

        QString fileList;           //播放列表
        QString filetext;
        QFile *q_file;
        ofstream *output_temp;               //temp文件

        int NOW_ROW = 2;

        bool is_created;
        bool is_playing = false;

        QTimer *check_time;
        int track_state[4];

        QString stylesheet_button;


signals:
        void press(int type);
        void longpress(int type);
        void release(int type);
        void CHANGE();
};

#endif // NOTATIONWINDOW_H
