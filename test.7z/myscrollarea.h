#ifndef MYSCROLLAREA_H
#define MYSCROLLAREA_H

#include<QWidget>
#include<QFile>
#include <QWidget>
#include<QPalette>

#include<QToolButton>
#include<QPixmap>
#include<QBitmap>
#include<QMouseEvent>
#include<QPainter>
#include<QPaintEvent>
#include<QDebug>
#include<QColor>
#include<QtMultimedia/QMediaPlayer>
#include<QPen>
#include<QTimer>
#include<QVector>
#include<QWidget>
#include<QScrollArea>
#include<QLabel>
#include<QButtonGroup>
#include<QFileDialog>


using namespace std;

extern double BPM;

extern QString song_Check;    //选中的歌曲名字

const int num_of_song=3;    //歌曲数量

extern QString song_name[num_of_song+1];  //各选项名字

extern int key_num;



extern int combo;


extern int score;

extern int perfect_num;
extern int great_num;
extern int miss_num;
extern double accuray_num;
extern int highest_combo;

extern double scale;

class source
{
    source();

};

class CheckButton : public QToolButton
{
    Q_OBJECT
public:
    explicit CheckButton(QWidget *parent = nullptr,QString img="",QString="",QString="");
    void initAll(QWidget *parent = nullptr,QString img="",QString="",QString="");

protected:
    void paintEvent(QPaintEvent *);

signals:

public slots:

private:
    QString text;
    QString check;
    QString init;

    QMediaPlayer* select;
};
class myWidget : public QWidget
{
    Q_OBJECT
public:
    explicit myWidget(QWidget *parent = nullptr);
    void initAll(QWidget *parent = nullptr);



signals:

public slots:
};
class myScrollArea : public QScrollArea
{
    Q_OBJECT
public:
    explicit myScrollArea(QWidget *parent = nullptr);
    void initAll(QWidget *parent = nullptr);

    int current_song;

signals:
    void check();


protected:
    void keyPressEvent(QKeyEvent *);
    void keyReleaseEvent(QKeyEvent *event);

public slots:

private:
    myWidget* select_widget;
    CheckButton *song[num_of_song];
    QLabel *text[3];

};

#endif // MYSCROLLAREA_H
