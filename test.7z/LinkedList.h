#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include "stdio.h"
#include "stdlib.h"
#include <iostream>
#include<vector>
#include<QPropertyAnimation>
#include<QLabel>
#include<QDebug>
using namespace std;
struct ListNode{
    QLabel *label=new QLabel;
    QPropertyAnimation *animation=new QPropertyAnimation;
    int flag=0;
    struct ListNode* next=nullptr;
};
class ListNodeClass{

public:
    ListNodeClass(){
        mid=head;
    };
    ~ListNodeClass(){};
    ListNode *head=nullptr;
    ListNode *current=nullptr;
    int n=0;
    void setcurrentNode(){
        ListNode* newNode = new ListNode();
        ListNode* p = head;
        if (p == nullptr){
                head = newNode;
                current=head;
            }
        else{
            while (p->next != nullptr){
                p = p->next;
            }
            current=p;
        }
    };
    void insertNode(){
        ListNode* newNode = new ListNode;
        ListNode* p = head;
        if (head == nullptr){
            head = newNode;
        }
        else{
            while (head->next != nullptr){
                head = head->next;
            }
            head->next = newNode;
        }
        head=p;
        n++;
    }
    void deleteNode(){
        ListNode* p = head;
        //首先判断是不是空链表
        if (p == nullptr){
            return;
        }
        else{
            //如果有该结点，遍历到待删除节点的前一节点
            if(n==1&&head!=nullptr&&head->next==nullptr&&((head->animation->state()==QPropertyAnimation::Stopped)||(head->label->y()>629))){
                delete head->label;
                delete head->animation;
                head->label=new QLabel;
                head->animation=new QPropertyAnimation;
                head->flag=0;
                return;
            }
            while (head->next != nullptr && ((head->animation->state()==QPropertyAnimation::Stopped)||(head->label->y()>629))){
                p=head;
                head = head->next;
                p->flag=0;
                delete p->label;
                delete p->animation;
                delete p;
                n--;
            }
          }
        qDebug()<<"已经删除啦~"<<endl;
        qDebug()<<n<<endl;
        return;
    }
    void pauseNode(){
        if (head != nullptr){
            ListNode* save_head;
            save_head=head;
            while (head != nullptr&&head->flag==1){
                head->animation->pause();
                head= head->next;
                qDebug()<<"已经暂停了";
            };
            head=save_head;
        };

    };
    void startNode(){
        if (head != nullptr){
            ListNode* save_head;
            save_head=head;
            while (head != nullptr&&head->flag==1){
                head->animation->start();
                head= head->next;
                qDebug()<<"已经继续了";
            };
            head=save_head;
        };
    };
private:
     ListNode *mid=nullptr;

};




#endif // LINKEDLIST_H
