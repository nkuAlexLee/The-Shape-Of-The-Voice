#include "digitalzoom.h"
#include <QPainter>
#include <QPaintEvent>
#include <QLabel>
#include<mainwindow.h>
DigitalZoom::DigitalZoom(QWidget *parent) : QWidget(parent)
{
    setAttribute(Qt::WA_TranslucentBackground, true);
    setWindowFlags(Qt::SplashScreen|Qt::FramelessWindowHint);
    //setWindowFlags(Qt::WindowStaysOnTopHint);

}

void DigitalZoom::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    if(m_bIsLeftMousePressMove){
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setPen(QPen(QColor(0, 160, 230), 5));
        painter.drawRect(event->rect());
    }else{
        painter.fillRect(this->rect(), QColor(0, 0, 0, 1));
    }
}

void DigitalZoom::mousePressEvent(QMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton)
    {
        m_startPoint = event->pos();
    }

    QWidget::mousePressEvent(event);
}

void DigitalZoom::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton){
        m_endPoint = event->pos();
        m_bIsLeftMousePressMove = true;
        update(QRect(m_startPoint,m_endPoint));
    }
}

void DigitalZoom::mouseReleaseEvent(QMouseEvent *event)
{
    if(m_bIsLeftMousePressMove){
        m_bIsLeftMousePressMove = false;
    }

    update();
}
void DigitalZoom::set(void (*func)(DigitalZoom*m_digitalZoomWidget))
{
    func(this);
    update();
}
DigitalZoom::~DigitalZoom(){
        delete (MainWindow*)mainPtr;

}
