#include "gameoverwindow.h"
#include "ui_gameoverwindow.h"
#include"GlobalData2.h"
#include<QUrl>
#include<selectmusicwindow.h>
#include<mainwindow.h>
GameOverWindow::GameOverWindow(QWidget *parent,float finishnumber,int successPress,int scorenumber,QString filename) :
    QWidget(parent),
    ui(new Ui::GameOverWindow)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
    setWindowFlags(Qt::WindowStaysOnTopHint);
    ui->filename->setText(filename);
    finished=finishnumber;
    success_press=successPress;
    total_score=scorenumber;
    strfinished=QString::number((int)finished)+"%";
    strsuccess_press=QString::number(success_press);
    strscore=QString::number(total_score);
    ui->finished->setText(strfinished);
    ui->success->setText(strsuccess_press);
    ui->score->setText(strscore);
    if(finished>=90){
        ui->ScorePic->setPixmap(QPixmap(":/pic/picture/S.png"));
    }
    else if (finished>=80) {
        ui->ScorePic->setPixmap(QPixmap(":/pic/picture/A.png"));
    }
    else if (finished>=70) {
        ui->ScorePic->setPixmap(QPixmap(":/pic/picture/B.png"));
    }
    else{
        ui->ScorePic->setPixmap(QPixmap(":/pic/picture/d.png"));
    }
    if(finishnumber>readHighFinished(filename,0,0)){
        readHighFinished(filename,finishnumber,1);
    }
    if(scorenumber>readHighScore(filename,0,0)){
        readHighScore(filename,scorenumber,1);
    }
}

GameOverWindow::~GameOverWindow()
{
    delete ui;
}
void GameOverWindow::screenShots(){
    int ID=this->winId();
        //qDebug()<<"ID="<<ID<<endl;
        QScreen *screen = QGuiApplication::primaryScreen();
        screen->grabWindow(ID).save("score.jpg",0);
}




void GameOverWindow::on_backpushButton_clicked()
{
    this->close();
    SelectMusicWindow *s=new SelectMusicWindow;
    s->p=this->p;
    ((MainWindow*)(s->p))->player->play();
    s->show();
}


void GameOverWindow::on_screenshotbackpushButton_pressed()
{
    screenShots();
    ui->screenshotbackpushButton->setText("成功");
}


void GameOverWindow::on_screenshotbackpushButton_released()
{
    ui->screenshotbackpushButton->setText("截图");
}

