#include "begin.h"
#include "ui_begin.h"
#include"GlobalData2.h"
#include"UIdesign.h"
Begin::Begin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Begin)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
    setWindowFlags(Qt::WindowStaysOnTopHint);
    playInterimgif2();
    music_volume=readGameMusic(50,0);
    qDebug()<<music_volume;
    backgroundmusic_volume=readBackGroundMusic(50,0);
    qDebug()<<backgroundmusic_volume;
    //backgroundmusic_volume=readBackGroundMusic(50,0);
    leftmost_track=readKey(0,0,0);
    left_track=readKey(1,0,0);
    right_track=readKey(2,0,0);
    rightmost_track=readKey(3,0,0);
    medialist->addMedia(QUrl::fromLocalFile(".\\resourse\\video\\TheJourneyofElaina.mp4"));
    musiclist->addMedia(QUrl::fromLocalFile(".\\resourse\\video\\HwVideoEditor.mp3"));
    backgroundmusic->setPlaylist(musiclist);
//    medialist->addMedia(QUrl("qrc:/video/video/TheJourneyofElaina.mp4"));
//    medialist->setPlaybackMode(QMediaPlaylist::Loop);
//    musiclist->addMedia(QUrl("qrc:/video/video/HwVideoEditor.mp3"));
//    musiclist->setPlaybackMode(QMediaPlaylist::Loop);


}

//Begin::~Begin()
//{
//    delete ui;
//}
