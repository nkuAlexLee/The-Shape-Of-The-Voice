#include "settingwindow.h"
#include "ui_settingwindow.h"
#include "mainwindow.h"
#include"UIdesign.h"
#include"GlobalData2.h"
#include<QChar>
settingwindow::settingwindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::settingwindow)
{

    ui->setupUi(this);

    this->setWindowIcon(QIcon(":/img/resourse/picture/bitbug_favicon.ico"));
    this->setWindowTitle("声之形");
    setFixedSize(this->width(), this->height());
    setWindowFlags(Qt::WindowStaysOnTopHint);
//    QString num = QString::number(qrand()%15+1);
//    ui->PictureLabel->setPixmap(QPixmap(":/pic/picture/background ("+num+").png"));
    ui->lineEdit_1->setText((QString)((char)leftmost_track));
    ui->lineEdit_2->setText((QString)((char)left_track));
    ui->lineEdit_3->setText((QString)((char)right_track));
    ui->lineEdit_4->setText((QString)((char)rightmost_track));
    ui->gamemusicVolume->setValue(music_volume);
    ui->backgroundmusicVolume->setValue(backgroundmusic_volume);
}

settingwindow::~settingwindow()
{
    delete ui;
}

void settingwindow::on_BackButtom_clicked()
{
    goToOtherPage();
}
void settingwindow::goToOtherPage()
{
    p=new MainWindow(this,(((MainWindow*)p))->player,(((MainWindow*)p))->medialist,(((MainWindow*)p))->backgroundMusic,(((MainWindow*)p))->musiclist);
    ((MainWindow*)p)->hide();
    this->playInterimgif1();
    QTimer::singleShot(3000,this, [=](){
        this->close();
        ((MainWindow*)p)->show();
        ((MainWindow*)p)->m_digitalZoomWidget->show();
    });
}

void settingwindow::on_BackButtom_2_clicked()
{
    readGameMusic(ui->gamemusicVolume->value(),1);
    music_volume=readGameMusic(0,0);
    readBackGroundMusic(ui->backgroundmusicVolume->value(),1);
    qDebug()<<"进度条的值"<<ui->backgroundmusicVolume->value();
    backgroundmusic_volume=readBackGroundMusic(0,0);
    qDebug()<<backgroundmusic_volume;
    ((MainWindow*)p)->backgroundMusic->pause();
    ((MainWindow*)p)->backgroundMusic->setVolume(backgroundmusic_volume);
    ((MainWindow*)p)->backgroundMusic->play();
    if(ui->lineEdit_1->text()!=""){
        QByteArray array1 =ui->lineEdit_1->text().toLatin1();
        leftmost_track=(int)array1.at(0);
        qDebug()<<leftmost_track;
    }
    if(ui->lineEdit_2->text()!=""){
        QByteArray array2 =ui->lineEdit_2->text().toLatin1();
        left_track=(int)array2.at(0);
        qDebug()<<left_track;
    }
    if(ui->lineEdit_3->text()!=""){
        QByteArray array3 =ui->lineEdit_3->text().toLatin1();
        right_track=(int)array3.at(0);
        qDebug()<<right_track;
    }
    if(ui->lineEdit_4->text()!=""){
        QByteArray array4 =ui->lineEdit_4->text().toLatin1();
        rightmost_track=(int)array4.at(0);
        qDebug()<<rightmost_track;
    }
    readKey(0,leftmost_track,1);
    readKey(1,left_track,1);
    readKey(2,right_track,1);
    readKey(3,rightmost_track,1);
    ui->lineEdit_1->setText((QString)((char)leftmost_track));
    ui->lineEdit_2->setText((QString)((char)left_track));
    ui->lineEdit_3->setText((QString)((char)right_track));
    ui->lineEdit_4->setText((QString)((char)rightmost_track));
}


void settingwindow::on_BackButtom_3_clicked()
{
    music_volume=readGameMusic(0,0);
    backgroundmusic_volume=readBackGroundMusic(0,0);
    ((MainWindow*)p)->backgroundMusic->pause();
    ((MainWindow*)p)->backgroundMusic->setVolume(backgroundmusic_volume);
    ((MainWindow*)p)->backgroundMusic->play();
    readKey(0,leftmost_track,1);
    readKey(1,left_track,1);
    readKey(2,right_track,1);
    readKey(3,rightmost_track,1);
    ui->lineEdit_1->setText((QString)((char)leftmost_track));
    ui->lineEdit_2->setText((QString)((char)left_track));
    ui->lineEdit_3->setText((QString)((char)right_track));
    ui->lineEdit_4->setText((QString)((char)rightmost_track));
    ui->backgroundmusicVolume->setValue(backgroundmusic_volume);
    ui->gamemusicVolume->setValue(music_volume);
}

