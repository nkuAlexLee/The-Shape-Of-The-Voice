#include "mainwindow.h"
#include <QApplication>
#include"begin.h"
#include<GlobalData2.h>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    Begin *b=new Begin;
    b->show();
    MainWindow *w=new MainWindow(nullptr,b->player,b->medialist,b->backgroundmusic,b->musiclist);
    w->hide();
    QTimer::singleShot(7000,b, [=](){
        w->show();
        w->m_digitalZoomWidget->show();
        b->close();
    });
    //MainWindow w(b,b->player,b->medialist,b->backgroundmusic,b->musiclist);

    return a.exec();
}
