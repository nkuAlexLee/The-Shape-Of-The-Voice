#ifndef DIGITALZOOM_H
#define DIGITALZOOM_H

#include <QWidget>
#include <QUrl>
//要包含下面的两个文件，必须在.pro文件中添加  QT += multimedia  multimediawidgets
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QMediaPlaylist>
#include <QWidget>
#include <QPushButton>
#include "qpixmap.h"
#include <QLabel>
#include <QPixmap>
#include <QColor>
#include <QPainter>
#include <QMoveEvent>
#include <QMessageBox>
#include <QDebug>
#include <QThread>
#include <QMediaMetaData>
#include <QTimer>
#include <QStyle>
#include <QTime>
#include <QtGlobal>
#include <windows.h>
#include <QDir>
#include <QPropertyAnimation>
#include <QMovie>
class DigitalZoom : public QWidget
{
    Q_OBJECT
public:
    void* mainPtr= nullptr;
    explicit DigitalZoom(QWidget *parent = nullptr);
    QMediaPlayer *music;
    QLabel* transq=nullptr;
    QMovie* transmovie=nullptr;
    ~DigitalZoom();
    void mainHide(){
        this->close();
        //music->stop();
    };
    void set(void (*func)(DigitalZoom*m_digitalZoomWidget));
    void playInterimgif1(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim1.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };
    void playInterimgif2(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim2.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

signals:

public slots:

protected:
    QPoint m_startPoint; /* 鼠标按下位置 */
    QPoint m_endPoint;  /* 鼠标移动后的位置 */
    bool m_bIsLeftMousePressMove = false; /* 鼠标左键按下移动标志 */
};

#endif // DIGITALZOOM_H
