#include "GlobalData2.h"

int usage_patterns=0;//0是默认，1是游戏模式，2是编谱模式
int leftmost_track='S';      //最左
int left_track='F';          //左
int right_track='J';         //右
int rightmost_track='L';     //最右
int music_volume=50;         //初始值50
int backgroundmusic_volume=50;
int game_time=0;
long long int music_time=0;
long long int now_time=0;
int wait_time=0;

QString music_txt="";               //音乐谱子
QString music_name="";               //音乐
