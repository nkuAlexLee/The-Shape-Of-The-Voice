#ifndef GLOBALDATA2_H
#define GLOBALDATA2_H
/*<-------------全局数据------------->*/
#include <QString>
extern int usage_patterns;
extern int leftmost_track;      //最左
extern int left_track;          //左
extern int right_track;         //右
extern int rightmost_track;     //最右
extern int music_volume;        //游戏音乐声音大小
extern int backgroundmusic_volume;  //游戏背景音乐大小
extern int game_time;           //游戏时间
extern long long int music_time;        //音乐时长
extern long long int now_time;          //当前时刻
extern bool allow_press;
extern int wait_time;                  //等待时间
extern QString music_txt;               //音乐谱子
extern QString music_name;
#endif // GLOBALDATA2_H
