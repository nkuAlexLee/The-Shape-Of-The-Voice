#ifndef SELECTMUSICWINDOW_H
#define SELECTMUSICWINDOW_H

#include <QWidget>
#include<QMediaPlayer>
#include<QLabel>
#include<QMovie>
#include<QFile>
namespace Ui {
class SelectMusicWindow;
}

class SelectMusicWindow : public QWidget
{
    Q_OBJECT

public:
    explicit SelectMusicWindow(QWidget *parent = nullptr);
    ~SelectMusicWindow();
    void goToOtherPage();
    void *p;
    void init();
    QLabel* transq=nullptr;
    QMovie* transmovie=nullptr;
    QStringList fileList;  //文件名称
    QStringList *lrcList=new QStringList();
    QMediaPlaylist *PlayerList;
    QMediaPlayer *Player;
    QString *Spectrum;
    QString fileName;
    QStringList getFileNames(const QString &path);
    QStringList getLrcNames(const QString &path); //获取路径下所有文件名
    void addItem(QString name);
    QString MusicPath="D:\\QTfile\\test\\music_game_data\\player\\music";
    QString LrcPath="D:\\QTfile\\test\\music_game_data\\player\\file";
    QString loadStyle(QString const website);
    void playInterimgif1(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim1.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };
    void playInterimgif2(){
        transq=new QLabel(this);
        transmovie = new QMovie(":/pic/picture/interim2.gif");
        transq->setMovie(transmovie);
        transq->setGeometry(0,0,1280,720);
        transq->setParent(this);
        transmovie->start();
        transq->show();
        connect(transmovie,&QMovie::stateChanged,[=](){
            if(transmovie!=nullptr){
                delete transmovie;
                delete transq;
            }
        });
    };
    QString substring(QString str,int left,int right){
        QString restr="";
        for(int i=left-1;i<right;i++){
            restr+=str[i];
        }
        return restr;
    }

    int readHighScore(QString musicname,int score,int type){
        int highscore=0;
        int l=musicname.size();
        QString address=".\\music_game_data\\system\\music\\musicHighScore.txt";/*<-------------文件地址------------->*/
        QString message="";
        QString strscore;
        if(type==0){
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                message=read.readLine();
                if(musicname==substring(message,1,l)){
                    strscore=substring(message,l+1,message.size()-1);
                    qDebug()<<strscore;
                    break;
                }
                qDebug()<<musicname;
            }while(!read.atEnd());
            highscore=strscore.toInt();
            music_score_txt.close();
            qDebug()<<highscore;
            return highscore;
        }else if(type==1){
            int m=0;
            QString s = QString("%1").arg(score),s11;
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "乐谱文件打开失败 Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            while(!read.atEnd()){
                s11=read.readLine();
                if(musicname==substring(s11,1,l)){
                    strscore=substring(s11,l+1,s11.size()-1);
                    highscore=strscore.toInt();
                    if(highscore<score){
                        message+=musicname+s+"$";
                        m++;
                        continue;
                    }
                }
                message+=s11;
            }
            music_score_txt.close();
            if(m==0){
               message+=musicname+s+"$";
            }
            if(!music_score_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            QTextStream txtOutput(&music_score_txt);
            QString s1="";
                    for(int i=0;i<message.size();i++){
                        if(message[i]=='&'){
                            s1+=message[i]+"\n";
                        }else{
                            s1+=message[i];
                        }
                    }
                    txtOutput << s1 << endl;
                    music_score_txt.close();
        return 1;
        }
        return 0;
    }

    float readHighFinished(QString musicname,float finish,int type){
        float highfinish=0;
        int l=musicname.size();
        QString address=".\\music_game_data\\system\\music\\musicHighFinished.txt";/*<-------------文件地址------------->*/
        QString message="";
        QString strfinish;
        if(type==0){
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            do{
                message=read.readLine();
                if(musicname==substring(message,1,l)){
                    strfinish=substring(message,l+1,message.size()-1);
                    break;
                }
                qDebug()<<"finished:"<<musicname;
            }while(!read.atEnd());
            highfinish=strfinish.toFloat();
            music_score_txt.close();
            qDebug()<<"outer highfinish:"<<highfinish;
            return highfinish;
        }else if(type==1){
            int m=0;
            QString s = QString("%1").arg(finish),s11;
            QFile music_score_txt(address);
            if(!music_score_txt.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                qDebug() << "文件打开失败 Open failed" << endl;
                return 0;
            }
            QTextStream read(&music_score_txt);
            while(!read.atEnd()){
                s11=read.readLine();
                if(musicname==substring(s11,1,l)){
                    strfinish=substring(s11,l+1,s11.size()-1);
                    highfinish=strfinish.toInt();
                    if(highfinish<finish){
                        message+=musicname+s+"$";
                        m++;
                        continue;
                    }
                }
                message+=s11;
            }
            music_score_txt.close();
            if(m==0){
               message+=musicname+s+"$";
            }
            if(!music_score_txt.open(QIODevice::WriteOnly | QIODevice::Text)){
                qDebug() << "Open failed." << endl;
                return 0;
            }
            QTextStream txtOutput(&music_score_txt);
            QString s1="";
                    for(int i=0;i<message.size();i++){
                        if(message[i]=='&'){
                            s1+=message[i]+"\n";
                        }else{
                            s1+=message[i];
                        }
                    }
                    txtOutput << s1 << endl;
                    music_score_txt.close();
        return 1;
        }
        return 0;
    }

    void playdegree(int score,float finished,QLabel *label,QLabel *Score,QLabel *Finished){
        label->setGeometry(950,90,271,211);
        if(finished>=90){
            label->setPixmap(QPixmap(":/pic/picture/s_best.png"));
        }
        else if (finished>=80) {
            label->setPixmap(QPixmap(":/pic/picture/a_best.png"));
        }
        else if (finished>=70) {
            label->setPixmap(QPixmap(":/pic/picture/b_best.png"));
        }
        else{
            label->setPixmap(QPixmap(":/pic/picture/d_best.png"));
        };
        Score->setText(QString::number(score));
        Finished->setText(QString::number(finished)+"%");
    };

private slots:
    void seekMusic(int i,int );
    void on_BackButtom_2_clicked();

    void on_BackButtom_clicked();

private:
    Ui::SelectMusicWindow *ui;
};

#endif // SELECTMUSICWINDOW_H
