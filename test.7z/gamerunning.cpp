#include "gamerunning.h"
#include "GlobalData2.h"

#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QString>
#include <QMediaPlayer>
#include <QSoundEffect>
#include <QKeyEvent>
#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QDialog>

GameRunning::GameRunning(QWidget *parent) : QWidget(parent)
{

}

void GameRunning::beginRun(){
    qDebug()<<"beginRun"<<endl;
    //coreMusicGame(music_name,usage_patterns);
}

void GameRunning::musicEnd(){
    qDebug()<<"结束"<<mpattern<<endl;
    if(mpattern==1){

    }else if(mpattern==2){
        qDebug()<<"文件重写"<<endl;
        QFile f(music_txt_address);
        if(!f.open(QIODevice::WriteOnly | QIODevice::Text)){
            qDebug() << "Open failed." << endl;
            return;
        }

        QTextStream txtOutput(&f);
        //QString s1="0000\n0000\n0000\n0000\n0000\n0000\n0000";//700ms
        QString s1="";
        for(int i=0;i<music_score.size();i++){
            if(i%4==0&&i!=0){
                s1+="\n"+music_score[i];
            }else{
                s1+=music_score[i];
            }
        }
        txtOutput << s1 << endl;
        f.close();
    }
}

void GameRunning::coreMusicGame(QString musicname,int pattern){
    qDebug()<<"coreMusicGame"<<musicname<<pattern<<endl;
    if(pattern==1){

    }else if(pattern==2){

    }
}

void GameRunning::leftMostSlot(int ptime,int rtime){
    qDebug()<<"over leftMostSlot"<<ptime<<"~"<<rtime<<endl;
    if(usage_patterns==1){

    }else if(usage_patterns==2){
        if(rtime-ptime<=300){
            music_score[ptime/100*4+wait*4]='1';
        }else{
            for(int i=ptime/100*4;i<=rtime/100*4;i+=4){
                music_score[i+wait*4]='2';
            }
        }
    }
}

void GameRunning::leftSlot(int ptime,int rtime){
    qDebug()<<"over leftSlot"<<ptime<<"~"<<rtime<<endl;
    if(usage_patterns==1){

    }else if(usage_patterns==2){
        if(rtime-ptime<=300){
            music_score[ptime/100*4+1+wait*4]='1';
        }else{
            for(int i=ptime/100*4+1;i<=rtime/100*4+1;i+=4){
                music_score[i+wait*4]='2';
            }
        }
    }
}

void GameRunning::rightSlot(int ptime,int rtime){
    qDebug()<<"over rightSlot"<<ptime<<"~"<<rtime<<endl;

    if(usage_patterns==1){

    }else if(usage_patterns==2){
        if(rtime-ptime<=300){
            music_score[ptime/100*4+2+wait*4]='1';
        }else{
            for(int i=ptime/100*4+2;i<=rtime/100*4+2;i+=4){
                music_score[i+wait*4]='2';
            }
        }
    }
}

void GameRunning::rightMostSlot(int ptime,int rtime){
    qDebug()<<"over rightMostSlot"<<ptime<<"~"<<rtime<<endl;

    if(usage_patterns==1){

    }else if(usage_patterns==2){
        if(rtime-ptime<=300){
            music_score[ptime/100*4+3+wait*4]='1';
        }else{
            for(int i=ptime/100*4+3;i<=rtime/100*4+3;i+=4){
                music_score[i+wait*4]='2';
            }
        }
    }
}

void GameRunning::musicMess(QString musicmess,int pattern){
    qDebug()<<"musicMess"<<pattern<<endl;
    music_tx=musicmess;
    QString system="music_game_data//system//";
    QString player="music_game_data//player//";
    music_tx[music_tx.size()-1]='t';
    music_tx[music_tx.size()-2]='x';
    music_tx[music_tx.size()-3]='t';
    if(pattern==1)/*游戏模式*/{
        //music_txt_address=system+"file//"+music_tx+".txt";
        music_txt_address=system+"file//"+music_tx;
    }else if(pattern==2)/*编谱模式*/{
        //music_txt_address=player+"file//"+music_tx+".txt";
        music_txt_address=player+"file//"+music_tx;
    }else{
        qDebug()<<"pattern 模式值错误"<<endl;
        return;
    }
    QFile music_message(music_txt_address);     //音乐乐谱文件
    if(!music_message.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "乐谱文件打开失败 Open failed" << endl;
        return;
    }
    QTextStream read(&music_message);
    while(!read.atEnd()){
        music_score+=read.readLine();
    }
    for(int i=0;i<music_score.size();i++){
        if(music_score[i]!='0'){
            music_score[i]='0';
        }
    }
    qDebug()<<music_score<<endl;
    /*<-------------------乐谱读取完毕------------------->*/
    music_message.close();              //关闭乐谱文件
    mpattern=pattern;
    coreMusicGame(music_tx,mpattern);
}

void GameRunning::receiveTime(int time){
    now_ptime=time;
    if(now_ptime%1000==0){
        qDebug()<<"当前游戏时间："<<now_ptime<<endl;
    }
    if(now_ptime>=200){



        keyJudgmentFunction();
    }
}
/*<--------------------按键判定函数-------------------->*/
void GameRunning::keyJudgmentFunction(){
    leftMostJudgmentFunction();
}

void GameRunning::leftMostJudgmentFunction(){


    if(leftmost_score==0){
        if(leftmost_allow_release==5&&music_score[now_ptime/100*4]!=0){
            failure_press++;
            leftmost_allow_press=0;
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(leftmost_allow_release==9){
            failure_press++;
            leftmost_allow_press=0;
            musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0);
            leftMostJudgmentFunction();
            return;
            /*<--------------长按不抬-------------->*/
        }
        if(leftmost_allow_press==0){
            if(music_score[now_ptime/100*4+4*(jtime1+jtime2-1)]=='1'){
                leftmost_allow_press=2;
            }if(music_score[now_ptime/100*4+4*(jtime1+jtime2-1)]=='2'){
                leftmost_allow_press=2;
            }
            if(music_score[now_ptime/100*4+4*(jtime1+jtime2)]=='1'){
                leftmost_allow_press=2;
            }
            if(music_score[now_ptime/100*4+4*(jtime1-1+jtime2)]=='1'){
                leftmost_allow_press=2;
            }
        }else if(leftmost_allow_press==2){
            if(music_score[now_ptime/100*4+4*jtime2]=='1'){
                leftmost_allow_press=1;
                leftmost_score=now_ptime/100*4+4*jtime2;
            }
            if(music_score[now_ptime/100*4+4*jtime2]=='2'&&music_score[now_ptime/100*4+4*(jtime2-1)]!='2'){
                leftmost_allow_press=1;
                leftmost_score=now_ptime/100*4+4*jtime2;
            }
        }else if(leftmost_allow_press==8){
            leftmost_allow_press=0;
            failure_press++;
            //leftmost_allow_release=5;
        }
    }else{
        if(leftmost_allow_press==1&&leftmost_allow_release==0){
            if(now_ptime/100*4-leftmost_score==8){
                //没按
                failure_press++;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0);
                leftMostJudgmentFunction();
                return;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==3){
            if(now_ptime/100*4-leftmost_score==8){
                //没抬
                failure_press++;
                leftmost_allow_release=5;
                leftmost_score=0;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==0){
                //成功
                success_press++;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0);
                leftMostJudgmentFunction();
                return;
        }else if(leftmost_allow_press==0&&leftmost_allow_release==4){
            //长按过程中 成功
            success_press++;
            if(music_score[now_ptime/100*4+jtime2*4]=='2'&&music_score[now_ptime/100*4+(jtime2+1)*4]!='2'){
                leftmost_score=now_ptime/100*4+jtime2*4;
                leftmost_allow_release=3;
            }
        }else if(leftmost_allow_press==0&&leftmost_allow_release==7){
            //长按过程中 提前抬起
            failure_press++;
            leftmost_allow_release=6;
        }else if(leftmost_allow_press==0&&leftmost_allow_release==6){
            //长按过程中 提前抬起
            if(music_score[now_ptime/100*4]!='2'){
                leftmost_allow_release=0;
                musicScoreAssignValue(&leftmost_allow_press,&leftmost_score,0);
                leftMostJudgmentFunction();
                return;
            }
        }
    }
}

/*<------------------游戏模式传递按键信息------------------>*/
void GameRunning::leftMostPress(){
    if(leftmost_allow_press==0){
        return;
    }else if(leftmost_allow_press==1){
        leftmost_allow_press=0;
        leftmost_allow_release=3;
    }else if(leftmost_allow_press==2){
        leftmost_allow_press=8;
        leftmost_allow_release=5;
    }
}

void GameRunning::leftPress(){

}

void GameRunning::rightPress(){

}

void GameRunning::rightMostPress(){

}

void GameRunning::leftMostRelease(){
    if(leftmost_allow_release==0){
        return;
    }else if(leftmost_allow_release==3){
        leftmost_allow_release=0;
        leftMostJudgmentFunction();//准确抬起
    }else if(leftmost_allow_release==4){
        leftmost_allow_release=7;
        leftMostJudgmentFunction();//长按时提前抬起
    }else if(leftmost_allow_release==5){
        leftmost_allow_release=9;//一直长按的抬起
        leftMostJudgmentFunction();
    }
}

void GameRunning::leftRelease(){

}

void GameRunning::rightRelease(){

}

void GameRunning::rightMostRelease(){

}

void GameRunning::musicScoreAssignValue(int *press,int *score,int type){
    if(music_score[now_ptime/100*4+type]=='1'&&now_ptime/100*4!=*score){
        *press=1;
        *score=now_ptime/100*4;
    }else if(music_score[now_ptime/100*4+type]=='2'&&now_ptime/100*4!=*score){
        *press=1;
        *score=now_ptime/100*4;
        /*<------------判断乐谱当前位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[now_ptime/100*4+4*(jtime2-1)+type]=='1'&&now_ptime/100*4+4*(jtime2-1)!=*score){
        *press=1;
        *score=now_ptime/100*4+4*(jtime2-1);
    }else if(music_score[now_ptime/100*4+4*(jtime2-1)+type]=='2'&&now_ptime/100*4+4*(jtime2-1)!=*score){
        *press=1;
        *score=now_ptime/100*4+4*(jtime2-1);
        /*<------------判断乐谱下一行位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[now_ptime/100*4+4*jtime2+type]=='1'&&now_ptime/100*4+4*jtime2!=*score){
        *press=1;
        *score=now_ptime/100*4+4*jtime2;
    }else if(music_score[now_ptime/100*4+4*jtime2+type]=='2'&&now_ptime/100*4+4*jtime2!=*score){
        *press=1;
        *score=now_ptime/100*4+4*jtime2;
        /*<------------判断当前乐谱下下一行位置情况，与之前判断的位置做比较------------>*/
    }else if(music_score[now_ptime/100*4+4*(1+jtime2)+type]=='1'&&now_ptime/100*4+4*(1+jtime2)!=*score){
        *press=2;
        *score=0;
    }else if(music_score[now_ptime/100*4+4*(1+jtime2)+type]=='2'&&now_ptime/100*4+4*(1+jtime2)!=*score){
        *press=2;
        *score=0;
        /*<------------判断当前乐谱下下下一行位置情况，与之前判断的位置做比较------------>*/
    }
}
/*<------------------游戏模式传递按键信息------------------>*/
